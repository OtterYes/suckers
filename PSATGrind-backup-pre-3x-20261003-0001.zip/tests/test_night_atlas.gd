extends SceneTree
var failures:=0
var g

func _initialize()->void:call_deferred("run")
func check(value:bool,message:String)->void:
	if not value:failures+=1;push_error(message)

func fresh()->void:
	g._apply_loaded({})
	g.atlas.active_trial={}
	g._next_question()

func rich()->void:
	g.s.life_correct=100000
	g.s.life_kp=1e12
	g.s.hard_correct=20000
	g.s.tests=100
	g.s.kp=1e9
	g.atlas.data().insight=100000
	g.atlas.data().mixed=100000
	g.atlas.data().purchases=1000
	g.atlas.data().best_streak=100
	g.atlas.data().trials={"precision":100,"breadth":100,"endurance":100}
	for skill in g.SKILLS:g.sk(skill.id).xp=40000;g.sk(skill.id).c=1000

func run()->void:
	g=load("res://main.tscn").instantiate()
	g.test_mode=true
	root.add_child(g)
	await process_frame
	g.set_process(false)
	check(g.questions.size()==153,"Original question bank preserved")
	check(g.atlas.nodes.size()==96,"96 progression steps")
	check(g.atlas.nodes.filter(func(n):return n.tier==1).size()==24,"24 Foundation steps")
	check(g.atlas.nodes.filter(func(n):return n.tier==2).size()==36,"36 specialization steps")
	check(g.atlas.nodes.filter(func(n):return n.tier==3).size()==36,"36 Archive steps")
	check(g.atlas.unlocked_tier()==1 and not g.atlas.claim("f01"),"Fresh save has honest gates")
	g._show("study")
	var expected:float=g.reward()
	g._on_answer(g.q.a)
	check(is_equal_approx(g.s.kp,expected),"Original answer payout retained before Atlas rewards")
	var balance:float=g.s.kp
	g._on_answer(g.q.a)
	check(g.s.kp==balance,"No duplicate answer rewards")
	check(g.atlas.claim("f01"),"First goal claimable after first correct")
	check(not g.atlas.claim("f01"),"No duplicate Atlas claims")
	check(g.atlas.data().insight==1,"Claim gives Insight once")
	for id in ["f02","f03","f04","f05"]:g.atlas.pin(id)
	check(g.atlas.data().pins.size()==3 and not "f02" in g.atlas.data().pins,"Pin limit replaces oldest goal")
	fresh()
	g.s.kp=1000
	g._on_hint()
	var post_hint:float=g.s.kp
	g._on_hint()
	check(g.s.kp==post_hint,"Repeated H cannot charge a used hint again")
	for i in 4:
		if g.choice_btns[i].disabled:g._on_answer(i);check(not g.answered_current,"Eliminated answer cannot be selected with keyboard")
	fresh()
	g.s.kp=100
	g._buy(g.UPGRADES[0])
	check(g.lvl("flash")==1 and g.s.kp==75,"Existing purchase price retained")
	check(g.upgrade_state(g.UPGRADES[2])=="LOCKED" and g.upgrade_lock(g.UPGRADES[2])=="Focus Lv 2","Deeper upgrades gate behind the previous one")
	g.s.kp=100000
	g._buy(g.UPGRADES[2])
	check(g.lvl("marker")==0,"Locked upgrade cannot be bought")
	g.s.lvls.focus=2
	check(g.upgrade_state(g.UPGRADES[2])=="AFFORDABLE" and g.recommended_upgrade()!="","Gate opens at Lv 2 and a next buy is recommended")
	check(g.atlas.rank_title()=="Night Student","Fresh rank title")
	g.s.lvls.sheet=4
	var before:float=g.s.kp
	g._buy(g.UPGRADES[3])
	check(g.s.kp==before and g.lvl("sheet")==4,"Maxed upgrade rejects purchase")
	fresh()
	var legacy:Dictionary={"kp":1663.75,"life_correct":1,"life_kp":1663.75,"run_kp":1663.75,"lvls":{"flash":2},"ach":["first"],"scholars":3,"weights":{"44":0.6},"skills":{"conv":{"xp":16.0,"a":4,"c":3}},"muted":true,"custom_future_field":"preserve"}
	g._apply_loaded(legacy)
	check(g.s.kp==legacy.kp and g.s.lvls.flash==2 and g.s.scholars==3,"Legacy KP, upgrades and prestige scholars preserved")
	check(g.s.skills.conv.xp==16 and g.s.weights["44"]==0.6 and g.s.ach==legacy.ach,"Mastery, weights and trophies preserved")
	check(g.s.custom_future_field=="preserve" and g.s.save_version==2,"Additive migration preserves unknown fields")
	check(g.atlas.data().insight_mark==1,"Legacy lifetime counter seeds Insight fairly")
	var path:="user://night_atlas_test.json"
	check(g._write_save(path),"Atomic save writes successfully")
	g.s.kp=444
	check(g._write_save(path),"Atomic overwrite and backup succeed")
	var loaded=JSON.parse_string(FileAccess.get_file_as_string(path))
	g._apply_loaded(loaded)
	check(g.s.kp==444 and g.s.custom_future_field=="preserve","Save/load round-trip")
	for suffix in ["",".bak",".tmp"]:
		if FileAccess.file_exists(path+suffix):DirAccess.remove_absolute(path+suffix)
	fresh();rich()
	for n in range(1,19):check(g.atlas.claim("f%02d"%n),"Foundation chain %d reachable"%n)
	check(g.atlas.unlocked_tier()==2,"Tier II unlocks after 18 steps")
	check(not g.atlas.claim("p02"),"Specialization prerequisite enforced")
	g.atlas.data().insight=0
	check(not g.atlas.claim("p01"),"Insight affordability enforced")
	g.atlas.data().insight=100000
	for node in g.atlas.nodes:
		if not g.atlas.claimed(node.id):check(g.atlas.claim(node.id),"Reachable node: "+node.id)
	check(g.atlas.data().claimed.size()==96 and g.atlas.unlocked_tier()==3,"All 96 goals reachable without circular locks")
	check(g.atlas.core_capacity()==22,"Endgame core reservoir grows")
	g.atlas.data().path="precision"
	check(g.atlas.xp_bonus()>=7,"Lens and Archive XP modifiers function")
	g.atlas.data().auto_buy=true
	g.atlas.data().selected_buy="flash"
	g.s.kp=100
	g.s.lvls={}
	g.atlas.automate()
	check(g.lvl("flash")==1 and g.s.kp==75,"Guarded automation buys once")
	g.s.kp=40
	g.atlas.automate()
	check(g.lvl("flash")==1,"Automation keeps a 50 percent reserve")
	g.s.kp=100000
	var insight_before:int=g.atlas.data().insight
	check(g.atlas.exchange() and g.atlas.data().insight==insight_before+2,"Advanced Research Exchange works")
	var stored:Array=g.atlas.data().claimed.duplicate()
	g.s.run_kp=10000
	g.s.sec.Math.a=20
	g._take_test()
	check(g.atlas.data().claimed==stored and is_equal_approx(g.s.kp,g.atlas.perk("head_start")) and g.s.lvls.get("group",0)==int(g.atlas.perk("keep_group")) and g.s.lvls.size()==1,"Prestige keeps Atlas, resets run resources, applies head-start perks")
	check(g.atlas.perk("head_start")==5500 and g.atlas.perk("kp")>=40,"Perk sums across lanterns, active discipline and crowns")
	check(g.atlas.rank_title()=="Keeper of the Night","Rank title reaches the final rank")
	check(g.ui.atlas_map.nodes.size()==96,"Sky map places all 96 stars")
	check(g.ui.tracker_goals().size()==3,"Tracker always offers three goals")
	# Trial flow uses real answer handler, including difficulty and repeat guards.
	fresh();rich()
	for n in range(1,25):g.atlas.claim("f%02d"%n)
	check(g.atlas.start_trial("precision"),"Precision trial starts after Foundation completion")
	var trial_count:int=g.atlas.data().trials.precision
	for i in 10:
		check(g.q.diff==3,"Precision trial serves Hard questions")
		g._on_answer(g.q.a)
		g._next_question()
	check(g.atlas.active_trial.is_empty() and g.atlas.data().trials.precision==trial_count+1,"Trial completion records once")
	check(g.atlas.start_trial("endurance"),"Endurance trial starts")
	for i in 6:g._on_answer((g.q.a+1)%4);g._next_question()
	check(g.atlas.active_trial.is_empty(),"Trial fails after allowed errors without soft-lock")
	for screen in ["home","study","skills","upgrades","atlas","psat"]:
		g._show(screen);g._refresh();g.ui.refresh(.12)
		check(g.screens[screen].visible,"Screen navigation: "+screen)
	g.atlas.data().reduced_motion=true
	check(is_instance_valid(g.ui.reveal),"Tier reveal overlay appears once a tier unlocks")
	if is_instance_valid(g.ui.reveal):
		g.ui.reveal.queue_free()
		await process_frame
	g.ui.celebrate("TEST","body",Color.WHITE)
	check(is_instance_valid(g.ui.reveal),"Celebration overlay can be raised on demand")
	g.ui.reveal.queue_free()
	await process_frame
	g.ui._settings()
	await process_frame
	check(is_instance_valid(g.ui.preferences),"Preferences functional")
	g.queue_free()
	await process_frame
	print("NIGHT ATLAS TESTS: ","PASS" if failures==0 else "FAIL (%d)"%failures)
	quit(0 if failures==0 else 1)
