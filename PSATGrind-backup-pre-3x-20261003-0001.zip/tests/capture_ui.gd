extends SceneTree
var g
var destination:=""
func _initialize()->void:call_deferred("run")
func shot(name:String)->void:
	g._refresh();g.ui.refresh(.12)
	await process_frame
	await process_frame
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png(destination.path_join(name+".png"))
func run()->void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--preview-dir="):destination=argument.trim_prefix("--preview-dir=")
	if destination=="":push_error("Pass --preview-dir=absolute-path");quit(1);return
	DirAccess.make_dir_recursive_absolute(destination)
	g=load("res://main.tscn").instantiate()
	g.test_mode=true
	root.add_child(g)
	await process_frame
	await shot("home")
	g.s.kp=210;g.s.lvls={"group":2,"flash":1}
	g._show("study")
	await shot("study")
	g._on_answer(g.q.a)
	await shot("answer")
	g._show("atlas")
	await shot("atlas-foundation")
	g.ui._open_node("p01")
	await shot("atlas-locked")
	g.s.life_correct=100000;g.s.life_kp=1e12;g.s.hard_correct=20000;g.s.tests=100
	g.atlas.data().insight=100000;g.atlas.data().mixed=100000;g.atlas.data().purchases=1000;g.atlas.data().best_streak=100
	g.atlas.data().trials={"precision":100,"breadth":100,"endurance":100}
	g.atlas.data().seen_tier=3
	for skill in g.SKILLS:g.sk(skill.id).xp=40000;g.sk(skill.id).c=1000;g.sk(skill.id).a=1200
	for n in range(1,25):g.atlas.claim("f%02d"%n)
	for path in ["p","s","a"]:
		for n in range(1,9):g.atlas.claim(path+"%02d"%n)
	while is_instance_valid(g.ui.reveal) or g.ui.pending.size()>0:
		if is_instance_valid(g.ui.reveal):g.ui.reveal.free()
		g.ui.pending.clear()
	g.ui._open_node("p09")
	await shot("atlas-specialization")
	g.ui._open_node("e01")
	await shot("atlas-archive")
	g.ui.atlas_map.zoom_by(0.5);g.ui.atlas_map.focus_point(Vector2(1280,630))
	await shot("atlas-overview")
	g.ui.celebrate("TIER III · THE NIGHT ARCHIVE","Six distant constellations ring the Observatory.",Color("f5ce83"))
	await shot("reveal")
	g.ui.reveal.queue_free()
	for screen in ["skills","upgrades","psat"]:
		g._show(screen);await shot(screen)
	root.content_scale_size=Vector2i(1920,1080);root.size=Vector2i(1920,1080)
	await process_frame;g.ui.responsive()
	g._show("atlas");await shot("atlas-1080p")
	g._show("home");await shot("home-1080p")
	root.content_scale_size=Vector2i(1024,600);root.size=Vector2i(1024,600)
	g._show("study");await shot("study-1024x600")
	g._show("atlas");await shot("atlas-1024x600")
	root.content_scale_size=Vector2i(900,720);root.size=Vector2i(900,720)
	g._show("study");await shot("study-compact")
	g._show("atlas");await shot("atlas-compact")
	root.content_scale_size=Vector2i(640,900);root.size=Vector2i(640,900)
	g._show("study");await shot("study-narrow")
	g._show("atlas");await shot("atlas-narrow")
	g._show("upgrades");await shot("upgrades-narrow")
	g.queue_free();await process_frame
	quit()
