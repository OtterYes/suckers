extends RefCounted
## Permanent progression layered over the original economy. No second KP loop.
## Every star carries `fx` (summed by perk()) plus one-time grants applied on claim.
const PATHS = ["precision", "synthesis", "automation"]
const PATH_NAMES = {"precision":"The Lens", "synthesis":"The Bridge", "automation":"The Engine"}
const CHAPTERS = ["First Light", "Deep Field", "Binary Stars", "The Observatory", "Event Horizon", "The Night Archive"]
const RANKS = [[0,"Night Student"],[6,"Lantern Bearer"],[12,"Margin Scholar"],[18,"Keeper of Lanterns"],[24,"Apprentice of the Sky"],[36,"Disciple"],[48,"Night Cartographer"],[60,"Observatory Fellow"],[72,"Deep Field Surveyor"],[84,"Archivist"],[96,"Keeper of the Night"]]
var game
var nodes: Array[Dictionary] = []
var by_id: Dictionary = {}
var active_trial: Dictionary = {}
var last_trial_message := ""

func _init(owner_game) -> void:
	game = owner_game
	_catalog()

func data() -> Dictionary:
	return game.s.atlas

func migrate() -> void:
	var defaults := {"version":1, "claimed":[], "new_nodes":[], "insight":0, "earned_insight":0, "insight_mark":int(game.s.life_correct), "pins":[], "path":"precision", "best_streak":int(game.s.streak), "mixed":0, "purchases":0, "core_clicks":0, "core_charge":5, "hint_tokens":0, "conversions":0, "trials":{"precision":0,"breadth":0,"endurance":0}, "seen_tier":1, "auto_buy":false, "auto_claim":false, "auto_convert":false, "review":false, "selected_buy":"flash", "reduced_motion":false, "challenge_wins":0, "crowns_seen":[]}
	if not game.s.get("atlas") is Dictionary:
		game.s.atlas = {}
	for key in defaults:
		if not game.s.atlas.has(key):
			game.s.atlas[key] = defaults[key]
	for key in ["precision","breadth","endurance"]:
		if not data().trials.has(key):
			data().trials[key] = 0
	data().claimed = data().claimed.filter(func(id): return by_id.has(id))
	data().pins = data().pins.filter(func(id): return by_id.has(id)).slice(0, 3)
	if not PATHS.has(data().path):
		data().path = "precision"
	for achievement in [["streak5",5],["streak10",10],["streak25",25]]:
		if achievement[0] in game.s.ach:
			data().best_streak = maxi(data().best_streak, achievement[1])
	data().best_streak = maxi(data().best_streak, game.s.streak)
	game.s["save_version"] = 2

func _add(id: String, title: String, tier: int, chapter: int, req: Dictionary, price: int, reward: String, path := "", fx := {}) -> void:
	var node := {"id":id,"title":title,"tier":tier,"chapter":chapter,"req":req,"price":price,"reward":reward,"path":path,"fx":fx,"index":nodes.size()}
	nodes.append(node)
	by_id[id] = node

func _catalog() -> void:
	var titles := ["Strike a Match","Margin Notes","First Orbit","Pocket Spark","Study Circle","Steady Hand","Two Languages","Borrowed Light","Open the Lens","Cross the Room","Second Wind","Return to Errors","The Long Desk","Hold the Thread","First Examination","A Brighter Core","Hard-won Insight","Eight Windows","Choose a Discipline","Night Routine","Constellation Ink","Shared Horizons","The Last Lantern","Open the Observatory"]
	var requirements := [{"correct":1},{"correct":5},{"correct":12,"levels":1},{"correct":20,"best_streak":3},{"correct":30,"purchases":1},{"correct":45,"best_streak":5},{"correct":60,"studied_skills":4},{"correct":80},{"correct":100,"max_level":2},{"correct":125,"studied_skills":8},{"correct":150,"kp":5000},{"correct":180},{"correct":220,"levels":8},{"correct":260,"best_streak":10},{"correct":300,"tests":1},{"correct":350},{"correct":420,"hard":10},{"correct":500,"min_level":2},{"correct":600},{"correct":700,"tests":2},{"correct":850,"hard":40},{"correct":1000,"levels":24},{"correct":1200,"best_streak":15},{"correct":1500,"trials":1}]
	# 24 distinct lantern rewards: [text, fx]
	var lanterns := [
		["+1% answer KP. The first lantern is lit.", {"kp":1}],
		["+1 skill XP on every correct answer.", {"xp":1}],
		["Streak bonus cap raised 25 → 30.", {"streak_cap":5}],
		["Study Core reservoir grows to 7 stored clicks.", {"core_cap":2}],
		["Study Group starts at Lv 1 after every PSAT.", {"keep_group":1}],
		["Hints cost 15% less.", {"hint_discount":15}],
		["+2% answer KP.", {"kp":2}],
		["Earn one free-hint token every 10 correct answers.", {}],
		["New random event: SECOND WIND restores +5 streak.", {"event_new":1}],
		["+1 skill XP on every correct answer.", {"xp":1}],
		["Streak bonus cap +5.", {"streak_cap":5}],
		["Unlock the Review Desk: revisit questions you missed.", {}],
		["+2 hours of offline earnings.", {"offline":2}],
		["Hold the Thread: 2% of correct answers pay 10x.", {"lucky":2}],
		["+10% Scholars from every PSAT.", {"scholar_pct":10}],
		["Study Core reservoir grows to 10; a new orbit appears.", {"core_cap":3}],
		["+3 Insight now, +1% answer KP forever.", {"insight":3,"kp":1}],
		["Unlock Tier II: three Disciplines open. +2% answer KP.", {"kp":2}],
		["Head start: every new run begins with 500 KP.", {"head_start":500}],
		["Hint-token capacity expands from 3 to 6.", {}],
		["+5% passive KP.", {"passive":5}],
		["+2% more chance of a 10x answer.", {"lucky":2}],
		["+5 Insight now, +2% answer KP forever.", {"insight":5,"kp":2}],
		["Foundation complete: all trials open, +4h offline cap, the core becomes an observatory.", {"offline":4}]]
	for i in 24:
		_add("f%02d" % (i + 1), titles[i], 1, i / 6, requirements[i], 0, lanterns[i][0], "", lanterns[i][1])
	var path_titles := {
		"precision":["Polish the Lens","Fine Adjustment","Deliberate Practice","Sharp Edges","Calibration","Examiner's Eye","Long Exposure","Stable Image","Streak Insurance","Difficult Light","Exacting Work","Prismatic Memory"],
		"synthesis":["Build a Bridge","Common Ground","Research Exchange","Shared Language","Two Perspectives","Mixed Insight","Across the River","Intersections","Connected Notes","Unified Method","Eight-way Link","Grand Synthesis"],
		"automation":["Lay the Tracks","Set a Reserve","Procurement Desk","Quiet Hours","Reliable Hands","Long Shift","The Night Clerk","Orderly Shelves","Archive Assistant","Closed Circuit","Research Relay","Autonomous Lab"]}
	# per-path rewards: [text, fx]; steps 3/6/9/12 change how systems work, the rest are varied, path-flavoured gains
	var path_rewards := {
		"precision":[
			["+2% answer KP while The Lens is active.", {"kp":2}],
			["Streak bonus cap +5 while The Lens is active.", {"streak_cap":5}],
			["While The Lens is active: +1 skill XP per correct answer.", {}],
			["Hints cost 10% less while The Lens is active.", {"hint_discount":10}],
			["3% of correct answers pay 10x while The Lens is active.", {"lucky":3}],
			["Unlock the Precision Trial (10 Hard correct, at most 2 errors).", {}],
			["+4% answer KP while The Lens is active.", {"kp":4}],
			["+1 skill XP per correct answer while The Lens is active.", {"xp":1}],
			["While The Lens is active, spend a hint token to protect a wrong-answer streak.", {}],
			["Study Core clicks pay +1 KP while The Lens is active.", {"core_kp":1}],
			["+6% answer KP while The Lens is active.", {"kp":6}],
			["While The Lens is active: every third Hard correct earns +1 Insight.", {}]],
		"synthesis":[
			["+2% answer KP while The Bridge is active.", {"kp":2}],
			["+1 skill XP per correct answer while The Bridge is active.", {"xp":1}],
			["Unlock Research Exchange: convert KP + study credits into Insight.", {}],
			["+5% passive KP while The Bridge is active.", {"passive":5}],
			["+2h offline earnings while The Bridge is active.", {"offline":2}],
			["While The Bridge is active: Mixed Review gives +1 skill XP.", {}],
			["+4% answer KP while The Bridge is active.", {"kp":4}],
			["+10% Scholars from every PSAT while The Bridge is active.", {"scholar_pct":10}],
			["While The Bridge is active: each completed trial awards +2 extra Insight.", {}],
			["+3 Insight on claim.", {"insight":3}],
			["+6% answer KP while The Bridge is active.", {"kp":6}],
			["Research Exchange grants 2 Insight per conversion instead of 1.", {}]],
		"automation":[
			["+4% passive KP while The Engine is active.", {"passive":4}],
			["+2h offline earnings while The Engine is active.", {"offline":2}],
			["Unlock guarded auto-buy: select an upgrade; retain half your KP.", {}],
			["+6% passive KP while The Engine is active.", {"passive":6}],
			["Head start +1000 KP on every new run while The Engine is active.", {"head_start":1000}],
			["Offline earnings cap +4 hours permanently.", {"offline":4}],
			["Study Group starts at +2 levels after every PSAT while The Engine is active.", {"keep_group":2}],
			["+8% passive KP while The Engine is active.", {"passive":8}],
			["Unlock auto-claim for completed, free Foundation steps.", {}],
			["Random events arrive 15% sooner while The Engine is active.", {"event_rate":15}],
			["+10% passive KP while The Engine is active.", {"passive":10}],
			["Unlock auto-convert at Research Exchange; requires Bridge step 3.", {}]]}
	for path in PATHS:
		for i in 12:
			var n := i + 1
			var req := {"correct":600 + n * n * 35, "foundation":18, "levels":12 + n * 2}
			if path == "precision": req["hard"] = n * n * 3
			if path == "synthesis": req["mixed"] = n * n * 12
			if path == "automation": req["tests"] = 1 + n / 3
			if n % 3 == 0: req["trials"] = maxi(1, n / 3)
			_add(path.left(1) + "%02d" % n, path_titles[path][i], 2, i / 6, req, 2 + n * 2, path_rewards[path][i][0], path, path_rewards[path][i][1])
	var end_names := [
		["Distant Signal","Chart the Sky","Three Instruments","The First Survey","Patient Observer","First Light Crown"],
		["Faint Traces","Measure the Dark","Wide-angle Study","The Second Survey","Signal from Noise","Deep Field Crown"],
		["Paired Suns","Mutual Orbit","Linked Disciplines","The Third Survey","Balanced Forces","Binary Crown"],
		["Raise the Dome","Eight Lenses","The Night Council","The Fourth Survey","Unbroken Record","Observatory Crown"],
		["Beyond the Rim","Gravity of Ideas","The Long Return","The Fifth Survey","Defy the Horizon","Horizon Crown"],
		["Gather the Stars","A Living Library","Every Discipline","The Final Survey","The Last Equation","Keeper of the Night"]]
	var correct_goals := [4000,7500,12500,20000,32000,50000]
	# each chapter crown adds its own signature power on top of the shared crown bonus
	var crown_extra := [
		["Random events arrive 10% sooner.", {"event_rate":10}],
		["+3% chance of a 10x answer.", {"lucky":3}],
		["+15% Scholars from every PSAT.", {"scholar_pct":15}],
		["Head start +5000 KP on every new run.", {"head_start":5000}],
		["Streak bonus cap +10.", {"streak_cap":10}],
		["+15% answer KP. The sky is complete.", {"kp":15}]]
	for chapter in 6:
		for step in 6:
			var n := chapter * 6 + step + 1
			var base: int = correct_goals[chapter]
			var req := {"correct":base + step * (300 + chapter * 150),"specializations":24,"min_level":4 + chapter,"kp":pow(10, 5 + chapter * 0.65)}
			match step:
				0: req["hard"] = 100 + chapter * chapter * 350
				1: req["tests"] = 5 + chapter * 6
				2: req["mixed"] = 1000 + chapter * 2000
				3: req["trial_types"] = 3; req["trials"] = 6 + chapter * 9
				4: req["best_streak"] = 20 + chapter * 5; req["trials"] = 8 + chapter * 10
				5: req["hard"] = 300 + chapter * chapter * 500; req["trials"] = 10 + chapter * 12
			var text := ""
			var fx := {}
			match step:
				0: text = "+%d%% permanent passive KP and +2 Insight." % (2 + chapter); fx = {"passive":2 + chapter}
				1: text = "+1 permanent skill XP per correct answer."; fx = {"xp":1}
				2: text = "Core charge capacity +2; %s gains a new satellite." % CHAPTERS[chapter]; fx = {"core_cap":2}
				3: text = "Trial payout +1 Insight permanently."; fx = {"trial_payout":1}
				4: text = "Core clicks gain +1 KP permanently."; fx = {"core_kp":1}
				5:
					text = "%s crown: +5%% permanent KP, +2h offline cap. %s" % [CHAPTERS[chapter], crown_extra[chapter][0]]
					fx = {"kp":5,"offline":2}
					fx.merge(crown_extra[chapter][1])
			_add("e%02d" % n,end_names[chapter][step],3,chapter,req,20 + chapter * 15 + step * 3,text,"",fx)

func claimed(id: String) -> bool:
	return id in data().claimed

func count(tier: int, path := "") -> int:
	var total := 0
	for id in data().claimed:
		if by_id.has(id) and by_id[id].tier == tier and (path == "" or by_id[id].path == path): total += 1
	return total

## Sum of an effect across claimed stars. Discipline stars only count while their path is active.
func perk(key: String) -> float:
	var total := 0.0
	for id in data().claimed:
		if not by_id.has(id): continue
		var node: Dictionary = by_id[id]
		if node.path != "" and node.path != data().path: continue
		total += float(node.fx.get(key, 0))
	return total

func rank_title() -> String:
	var claimed_count: int = data().claimed.size()
	var title := "Night Student"
	for rank in RANKS:
		if claimed_count >= rank[0]: title = rank[1]
	if title == "Disciple": title = "Disciple of " + PATH_NAMES[data().path]
	return title

func next_rank() -> Array:
	for rank in RANKS:
		if data().claimed.size() < rank[0]: return rank
	return [96, "Keeper of the Night"]

func unlocked_tier() -> int:
	if count(1) == 24 and count(2) >= 24 and PATHS.all(func(p): return count(2,p) >= 6) and metric("trials") >= 3 and game.s.tests >= 5: return 3
	return 2 if count(1) >= 18 else 1

func tier_progress(tier: int) -> float:
	match tier:
		2: return minf(1.0, count(1) / 18.0)
		3:
			var parts := [count(1) / 24.0, minf(1.0, count(2) / 24.0), minf(1.0, metric("trials") / 3.0), minf(1.0, game.s.tests / 5.0)]
			for p in PATHS: parts.append(minf(1.0, count(2, p) / 6.0))
			return parts.reduce(func(a, b): return a + b, 0.0) / parts.size()
	return 1.0

func prerequisites(node: Dictionary) -> bool:
	if node.tier > unlocked_tier(): return false
	var n := int(node.id.substr(1))
	if n > 1 and not claimed(node.id.left(1) + "%02d" % (n-1)): return false
	return true

func metric(key: String) -> float:
	match key:
		"correct": return game.s.life_correct
		"kp": return game.s.life_kp
		"hard": return game.s.hard_correct
		"best_streak": return data().best_streak
		"tests": return game.s.tests
		"purchases": return maxi(data().purchases, game.s.lvls.values().reduce(func(a,b): return a+b,0))
		"foundation": return count(1)
		"specializations": return count(2)
		"mixed": return data().mixed
		"trials": return data().trials.values().reduce(func(a,b): return a+b,0)
		"trial_types": return data().trials.values().filter(func(v):return v>0).size()
		"levels": return game.SKILLS.reduce(func(a,k): return a+game.skill_level(k.id),0)
		"min_level": return game.SKILLS.map(func(k):return game.skill_level(k.id)).min()
		"max_level": return game.SKILLS.map(func(k):return game.skill_level(k.id)).max()
		"studied_skills": return game.SKILLS.filter(func(k):return game.sk(k.id).c>0).size()
	return 0

func requirement_name(key: String) -> String:
	return {"correct":"Lifetime correct","kp":"Lifetime KP earned","hard":"Hard correct","best_streak":"Best streak","tests":"PSAT prestiges","purchases":"Upgrade purchases","foundation":"Foundation steps","specializations":"Specialization steps","mixed":"Mixed correct since Atlas","trials":"Trials completed","trial_types":"Different trial types","levels":"Combined skill levels","min_level":"Every skill level","max_level":"Highest skill level","studied_skills":"Skills answered correctly"}.get(key,key)

func progress(node: Dictionary) -> float:
	var value := 0.0
	for key in node.req: value += minf(1.0,metric(key)/maxf(node.req[key],1))
	return value / max(node.req.size(),1)

func ready(node: Dictionary) -> bool:
	return not claimed(node.id) and prerequisites(node) and node.req.keys().all(func(k):return metric(k)>=node.req[k])

func state_of(node: Dictionary) -> String:
	if claimed(node.id): return "COMPLETE"
	if not prerequisites(node): return "LOCKED"
	if ready(node): return "CLAIM" if data().insight>=node.price else "NEED INSIGHT"
	return "NEARLY THERE" if progress(node)>=0.8 else ("NEW · AVAILABLE" if node.id in data().new_nodes else "IN PROGRESS")

func claim(id: String) -> bool:
	if not by_id.has(id): return false
	var node: Dictionary = by_id[id]
	if not ready(node) or data().insight<node.price: return false
	data().insight -= node.price
	data().claimed.append(id)
	for candidate in nodes:
		if not claimed(candidate.id) and prerequisites(candidate) and candidate.id not in data().new_nodes:
			data().new_nodes.append(candidate.id)
	var grant: int = (2 if node.tier == 3 else 1) + int(node.fx.get("insight", 0))
	data().insight += grant
	data().earned_insight += grant
	data().pins.erase(id)
	game._play("trophy")
	game._toast("%s unlocked · %s" % [node.title,node.reward])
	if game.ui: game.ui.on_claim(node)
	game._save()
	return true

func pin(id: String) -> void:
	if id in data().pins: data().pins.erase(id)
	elif by_id.has(id) and not claimed(id):
		if data().pins.size()>=3: data().pins.pop_front()
		data().pins.append(id)
	game._save()

func recommendations() -> Array:
	var result: Array = data().pins.duplicate()
	for node in nodes:
		if result.size()>=3: break
		if node.id not in result and not claimed(node.id) and prerequisites(node): result.append(node.id)
	return result

func end_count(step: int) -> int:
	return data().claimed.filter(func(id):return id.begins_with("e") and (int(id.substr(1))-1)%6==step).size()

func kp_multiplier() -> float:
	return 1.0 + perk("kp") * 0.01

func passive_multiplier() -> float:
	return 1.0 + perk("passive") * 0.01

func xp_bonus() -> int:
	return int(perk("xp")) + int(data().path=="precision" and claimed("p03")) + int(data().path=="synthesis" and claimed("s06") and game.s.mode=="mixed")

func core_capacity() -> int:
	return 5 + int(perk("core_cap"))

func on_answer(correct: bool) -> void:
	data().best_streak = maxi(data().best_streak,game.s.streak)
	if correct:
		data().core_charge = core_capacity()
		if game.s.mode=="mixed": data().mixed += 1
		var new_insight: int = (int(game.s.life_correct) - int(data().insight_mark)) / 5
		if new_insight>0:
			data().insight += new_insight
			data().earned_insight += new_insight
			data().insight_mark += new_insight*5
		if claimed("f08") and int(game.s.life_correct)%10==0:
			data().hint_tokens = mini(data().hint_tokens+1,6 if claimed("f20") else 3)
		if data().path=="precision" and claimed("p12") and game.q.diff==3 and int(game.s.hard_correct)%3==0:
			data().insight+=1
			data().earned_insight+=1
	if not active_trial.is_empty():
		active_trial.attempts+=1
		if correct:
			active_trial.correct+=1
			active_trial.skills[game.q.skill]=true
		else: active_trial.errors+=1
		if active_trial.errors>active_trial.allowed:
			last_trial_message="Trial ended. No KP lost; try again when ready."
			active_trial={}
		elif active_trial.correct>=active_trial.target and (active_trial.kind!="breadth" or active_trial.skills.size()==8):
			data().trials[active_trial.kind]+=1
			var payout := 3 + int(perk("trial_payout")) + (2 if data().path=="synthesis" and claimed("s09") else 0)
			data().insight+=payout
			data().earned_insight+=payout
			last_trial_message="Trial complete · +%d Insight" % payout
			game._toast(last_trial_message)
			game._play("trophy")
			if game.ui: game.ui.celebrate("TRIAL COMPLETE", "%s trial · +%d Insight" % [active_trial.kind.capitalize(), payout], Color("f5ce83"))
			active_trial={}

func can_start_trial(kind: String) -> bool:
	if not active_trial.is_empty() or kind not in ["precision","breadth","endurance"]: return false
	if count(1)<12: return false
	if kind=="precision" and not (claimed("p06") or claimed("f24")): return false
	if kind=="precision" and not game.SKILLS.any(func(k):return game.skill_tier(k.id)==3): return false
	if kind=="breadth" and metric("min_level")<2: return false
	return true

func start_trial(kind: String) -> bool:
	if not can_start_trial(kind): return false
	active_trial={"kind":kind,"correct":0,"errors":0,"attempts":0,"skills":{},"target":10 if kind=="precision" else (16 if kind=="breadth" else 25),"allowed":2 if kind=="precision" else (4 if kind=="breadth" else 5)}
	game.s.mode="mixed"
	last_trial_message=""
	game._next_question()
	game._show("study")
	return true

func conversion_cost() -> float:
	return 500.0 * (1.0 + data().conversions*0.15)

func conversion_credits() -> int:
	return maxi(0, int(game.s.life_correct)/20 - int(data().conversions))

func exchange() -> bool:
	if not claimed("s03") or conversion_credits()<1 or game.s.kp<conversion_cost(): return false
	game.s.kp-=conversion_cost()
	data().conversions+=1
	var gained := 2 if claimed("s12") else 1
	data().insight+=gained
	data().earned_insight+=gained
	game._save()
	return true

func automate() -> void:
	if claimed("a03") and data().auto_buy:
		for upgrade in game.UPGRADES:
			if upgrade.id==data().selected_buy and game.cost(upgrade)<=game.s.kp*0.5:
				game._buy(upgrade)
				break
	if claimed("a09") and data().auto_claim:
		for node in nodes:
			if node.tier==1 and ready(node):
				claim(node.id)
				break
	if claimed("a12") and data().auto_convert and claimed("s03") and conversion_cost()<=game.s.kp*0.5:
		exchange()
