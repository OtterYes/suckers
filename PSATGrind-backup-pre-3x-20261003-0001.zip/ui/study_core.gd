extends Control
signal clicked
var rank := 0
var crew := 0
var reduced := false
var glow := 0.0
var press := 0.0

func _ready() -> void:
	custom_minimum_size=Vector2(180,150)
	var button:=Button.new()
	button.text=""
	button.tooltip_text="Study Core: earn micro-KP from stored charge. Correct answers refill it."
	button.set_anchors_and_offsets_preset(PRESET_FULL_RECT)
	for key in ["normal","hover","pressed"]: button.add_theme_stylebox_override(key,StyleBoxEmpty.new())
	button.pressed.connect(func():clicked.emit())
	add_child(button)
	resized.connect(queue_redraw)

func pulse() -> void:
	if reduced: return
	glow=1.0
	press=1.0

func _process(delta: float) -> void:
	if glow>0 or press>0:
		glow=maxf(0,glow-delta*2.5)
		press=maxf(0,press-delta*5)
		queue_redraw()

func _draw() -> void:
	var center:=Vector2(size.x/2,58)
	var accent:=Color("75e3d3") if rank<2 else (Color("bda6ff") if rank<3 else Color("f5ce83"))
	var radius:=29.0*(1.0+sin(press*PI)*.12)
	if glow>0:
		draw_circle(center,55,Color(accent,glow*.1))
	var points:=PackedVector2Array([center+Vector2(0,-radius),center+Vector2(radius,0),center+Vector2(0,radius),center+Vector2(-radius,0)])
	draw_colored_polygon(points,Color(accent,.13))
	for i in 4: draw_line(points[i],points[(i+1)%4],accent,2,true)
	draw_line(points[0],points[2],Color(accent,.5),1,true)
	draw_line(points[1],points[3],Color(accent,.5),1,true)
	draw_circle(center,6,accent)
	for orbit in rank:
		draw_arc(center,42+orbit*9,0,TAU,64,Color(accent,.35),1,true)
		draw_circle(center+Vector2.from_angle(orbit*1.7+.4)*(42+orbit*9),3,Color("f5ce83"))
	for i in 6:
		var x:=size.x/2+(i-2.5)*25
		var color:=Color("bda6ff") if i<crew else Color("344254")
		draw_circle(Vector2(x,118),4,color)
		draw_style_box(_body(color),Rect2(x-7,124,14,9))
		draw_line(Vector2(x-9,138),Vector2(x+9,138),accent if i<crew else color,2,true)

func _body(color:Color)->StyleBoxFlat:
	var style:=StyleBoxFlat.new()
	style.bg_color=color.darkened(.3)
	style.set_corner_radius_all(3)
	return style
