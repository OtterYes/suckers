extends Control
## The Night Atlas sky: all 96 stars of all three tiers on one pannable, zoomable chart.
## Tier I lanterns wind up the left, three Discipline constellations radiate from the hub,
## six Archive constellations ring the Observatory on the right. Locked tiers show as faint silhouettes.
signal selected(id: String)

const HUB := Vector2(1000, 640)
const OBSERVATORY := Vector2(2080, 560)
const WORLD := Vector2(2560, 1260)
const SHAPE := [Vector2(0.0, 0.3), Vector2(0.3, 0.0), Vector2(0.62, 0.22), Vector2(1.0, 0.1), Vector2(0.8, 0.75), Vector2(0.4, 1.0)]
const PATH_COLORS := {"precision": Color("8fd3ff"), "synthesis": Color("c7a7ff"), "automation": Color("f5ce83")}
const ARCHIVE_COLORS := [Color("75e3d3"), Color("8fd3ff"), Color("c7a7ff"), Color("f5ce83"), Color("ff9f7a"), Color("ffffff")]
const LANTERN := Color("75e3d3")
const SELECT := Color("bda6ff")
const DIM := Color("2b394c")

var atlas
var nodes := {}        # id -> {pos, node, btn, lbl, color}
var states := {}
var progress := {}
var selected_id := ""
var recommended := ""
var unlocked_tier := 1
var reduced := false
var canvas: Control
var titles := {}       # key -> Label (constellation captions)
var zoom := 1.0
var dragging := false
var pulse := 0.0
var dots: PackedVector2Array = []
var motion: Tween

func _ready() -> void:
	clip_contents = true
	custom_minimum_size = Vector2(300, 320)
	size_flags_vertical = SIZE_EXPAND_FILL
	mouse_filter = MOUSE_FILTER_STOP
	gui_input.connect(_input_view)
	canvas = Control.new()
	canvas.size = WORLD
	canvas.mouse_filter = MOUSE_FILTER_IGNORE
	canvas.draw.connect(_draw_canvas)
	add_child(canvas)
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	for i in 260:
		dots.append(Vector2(rng.randf() * WORLD.x, rng.randf() * WORLD.y))
	resized.connect(_clamp)

func setup(atlas_ref) -> void:
	atlas = atlas_ref
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	for n in atlas.nodes:
		var k: int = int(n.id.substr(1))
		var p := Vector2.ZERO
		var color: Color = LANTERN
		match n.tier:
			1:
				var c: int = n.chapter
				var shape: Vector2 = SHAPE[(k - 1) % 6] * Vector2(360, 150)
				if c % 2 == 1:
					shape.x = 360 - shape.x
				p = Vector2(110, 110 + c * 250) + shape
			2:
				var j: int = k - 1
				var base: float = {"precision": -1.32, "synthesis": -0.08, "automation": 1.08}[n.path]
				p = HUB + Vector2.from_angle(base + sin(j * 0.8) * 0.2) * (125 + j * 45)
				color = PATH_COLORS[n.path]
			3:
				var c: int = n.chapter
				var center := OBSERVATORY + Vector2.from_angle(-PI / 2 + c * TAU / 6) * 310
				p = center + (SHAPE[(k - 1) % 6] - Vector2(0.5, 0.5)) * Vector2(210, 120)
				color = ARCHIVE_COLORS[c]
		p += Vector2(rng.randf_range(-9, 9), rng.randf_range(-9, 9))
		var d: float = 30.0 if n.tier == 1 else (36.0 if n.tier == 2 else (46.0 if (k - 1) % 6 == 5 else 40.0))
		var btn := Button.new()
		btn.focus_mode = Control.FOCUS_NONE
		btn.custom_minimum_size = Vector2(d, d)
		btn.size = Vector2(d, d)
		btn.position = p - Vector2(d, d) / 2
		btn.mouse_default_cursor_shape = CURSOR_POINTING_HAND
		btn.pressed.connect(func(): selected.emit(n.id))
		canvas.add_child(btn)
		var lbl := Label.new()
		lbl.text = n.title
		lbl.add_theme_font_size_override("font_size", 11)
		lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		lbl.size = Vector2(150, 16)
		lbl.position = p + Vector2(-75, d / 2 + 3)
		lbl.mouse_filter = MOUSE_FILTER_IGNORE
		canvas.add_child(lbl)
		nodes[n.id] = {"pos": p, "node": n, "btn": btn, "lbl": lbl, "color": color, "d": d}
	_caption("t1", Vector2(290, 50), "I · THE LANTERNS", LANTERN)
	_caption("t2", HUB + Vector2(0, 24), "II · THE DISCIPLINES", Color("dbe6f5"))
	_caption("precision", HUB + Vector2.from_angle(-1.32) * 660, "THE LENS", PATH_COLORS.precision)
	_caption("synthesis", HUB + Vector2.from_angle(-0.08) * 660, "THE BRIDGE", PATH_COLORS.synthesis)
	_caption("automation", HUB + Vector2.from_angle(1.08) * 660, "THE ENGINE", PATH_COLORS.automation)
	_caption("t3", OBSERVATORY + Vector2(0, -6), "III · THE OBSERVATORY", Color("dbe6f5"))
	for c in 6:
		var center := OBSERVATORY + Vector2.from_angle(-PI / 2 + c * TAU / 6) * 310
		_caption("e%d" % c, center + Vector2(0, 92), atlas.CHAPTERS[c].to_upper(), ARCHIVE_COLORS[c])
	_set_zoom(0.85)
	focus_tier(1, false)

func _caption(key: String, at: Vector2, text: String, color: Color) -> void:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 13)
	l.add_theme_color_override("font_color", color)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.size = Vector2(260, 18)
	l.position = at - Vector2(130, 9)
	l.mouse_filter = MOUSE_FILTER_IGNORE
	canvas.add_child(l)
	titles[key] = l

## states: id -> state string from atlas.state_of; progress: id -> 0..1
func refresh(new_states: Dictionary, new_progress: Dictionary, chosen: String, tier: int, next_goal := "") -> void:
	states = new_states
	progress = new_progress
	selected_id = chosen
	unlocked_tier = tier
	recommended = next_goal
	for id in nodes:
		var e: Dictionary = nodes[id]
		var n: Dictionary = e.node
		var btn: Button = e.btn
		var state: String = states.get(id, "LOCKED")
		var locked_tier: bool = n.tier > unlocked_tier
		var col: Color = e.color
		var style := StyleBoxFlat.new()
		style.set_corner_radius_all(int(e.d / 2))
		style.set_border_width_all(3 if id == selected_id else 2)
		var text_col := col
		match state:
			"COMPLETE":
				style.bg_color = col
				style.border_color = col.lightened(0.3)
				text_col = Color("0b1019")
			"CLAIM":
				style.bg_color = Color("f5ce83")
				style.border_color = Color("fff2c7")
				text_col = Color("0b1019")
			"NEED INSIGHT":
				style.bg_color = Color("1c2130")
				style.border_color = Color("f5ce83")
			"NEARLY THERE", "NEW · AVAILABLE":
				style.bg_color = Color("1c2130")
				style.border_color = col
			"IN PROGRESS":
				style.bg_color = Color("161b26")
				style.border_color = col.darkened(0.35)
			_:
				style.bg_color = Color("121722")
				style.border_color = DIM
				text_col = DIM
		if id == selected_id:
			style.border_color = SELECT
		if id == recommended and state != "COMPLETE":
			style.shadow_color = Color(col, 0.45)
			style.shadow_size = 8
		var glyph := ""
		if state == "COMPLETE":
			glyph = "♛" if n.tier == 3 and (int(n.id.substr(1)) - 1) % 6 == 5 else "✓"
		elif state == "CLAIM":
			glyph = "!"
		elif locked_tier:
			glyph = ""
		btn.text = glyph
		btn.add_theme_font_size_override("font_size", 14)
		btn.add_theme_color_override("font_color", text_col)
		btn.add_theme_color_override("font_hover_color", text_col.lightened(0.2))
		btn.add_theme_color_override("font_pressed_color", text_col)
		for key in ["normal", "hover", "pressed"]:
			btn.add_theme_stylebox_override(key, style)
		btn.modulate = Color(1, 1, 1, 0.32) if locked_tier else Color.WHITE
		btn.tooltip_text = _tooltip(n, state, locked_tier)
		var lbl: Label = e.lbl
		lbl.visible = not locked_tier and zoom >= 0.75
		lbl.add_theme_color_override("font_color", Color("dbe6f5") if state == "COMPLETE" or state == "CLAIM" else (col.darkened(0.15) if state != "LOCKED" else Color("536780")))
	titles.precision.visible = unlocked_tier >= 2
	titles.synthesis.visible = unlocked_tier >= 2
	titles.automation.visible = unlocked_tier >= 2
	titles.t2.text = "II · THE DISCIPLINES" if unlocked_tier >= 2 else "II · THE DISCIPLINES   ·   finish 18 Lanterns"
	titles.t3.text = "III · THE OBSERVATORY" if unlocked_tier >= 3 else "III · THE OBSERVATORY   ·   a distant sky"
	for c in 6:
		titles["e%d" % c].visible = unlocked_tier >= 3
	canvas.queue_redraw()

func _tooltip(n: Dictionary, state: String, locked_tier: bool) -> String:
	if locked_tier:
		return "%s\nA distant sky. Unlock Tier %s first." % [n.title, "II" if n.tier == 2 else "III"]
	var pct := int(progress.get(n.id, 0.0) * 100)
	var line := "%s  ·  %s" % [n.title, state]
	if state != "COMPLETE":
		line += "  ·  %d%%" % pct
	return line + "\n" + n.reward

func _process(delta: float) -> void:
	if reduced or not is_visible_in_tree():
		return
	pulse += delta
	var k := 1.0 + 0.07 * sin(pulse * 4.0)
	for id in nodes:
		var st: String = states.get(id, "")
		var btn: Button = nodes[id].btn
		if st == "CLAIM" or id == recommended:
			btn.pivot_offset = btn.size / 2
			btn.scale = Vector2(k, k)
		elif btn.scale != Vector2.ONE:
			btn.scale = Vector2.ONE

func _draw_canvas() -> void:
	for d in dots:
		canvas.draw_circle(d, 1.0, Color("3a4a62"))
	# nebula glow behind crowned archive constellations and completed disciplines
	for c in 6:
		if states.get("e%02d" % (c * 6 + 6), "") == "COMPLETE":
			var center := OBSERVATORY + Vector2.from_angle(-PI / 2 + c * TAU / 6) * 310
			for r in [150.0, 100.0, 55.0]:
				canvas.draw_circle(center, r, Color(ARCHIVE_COLORS[c], 0.05))
	for path in PATH_COLORS:
		if states.get(path.left(1) + "12", "") == "COMPLETE":
			for j in 12:
				canvas.draw_circle(nodes[path.left(1) + "%02d" % (j + 1)].pos, 34, Color(PATH_COLORS[path], 0.05))
	# constellation lines
	var lanterns: Array = []
	for i in 24:
		lanterns.append("f%02d" % (i + 1))
	for i in 23:
		_link(lanterns[i], lanterns[i + 1])
	_link_pos(nodes["f24"].pos, HUB, states.get("f24") == "COMPLETE", Color("dbe6f5"), unlocked_tier < 2)
	for path in PATH_COLORS:
		var prefix: String = path.left(1)
		_link_pos(HUB, nodes[prefix + "01"].pos, states.get(prefix + "01") == "COMPLETE", PATH_COLORS[path], unlocked_tier < 2)
		for j in 11:
			_link(prefix + "%02d" % (j + 1), prefix + "%02d" % (j + 2))
	canvas.draw_arc(OBSERVATORY, 26, 0, TAU, 48, Color("dbe6f5", 0.6 if unlocked_tier >= 3 else 0.2), 2, true)
	for c in 6:
		var first := "e%02d" % (c * 6 + 1)
		_link_pos(OBSERVATORY, nodes[first].pos, states.get(first) == "COMPLETE", ARCHIVE_COLORS[c], unlocked_tier < 3)
		for j in 5:
			_link("e%02d" % (c * 6 + j + 1), "e%02d" % (c * 6 + j + 2))
	# progress arcs and highlight rings
	for id in nodes:
		var e: Dictionary = nodes[id]
		var n: Dictionary = e.node
		if n.tier > unlocked_tier:
			continue
		var st: String = states.get(id, "LOCKED")
		var r: float = e.d / 2 + 5
		if st != "COMPLETE" and st != "LOCKED":
			var frac: float = progress.get(id, 0.0)
			canvas.draw_arc(e.pos, r, 0, TAU, 40, Color(e.color, 0.15), 2, true)
			if frac > 0.01:
				canvas.draw_arc(e.pos, r, -PI / 2, -PI / 2 + TAU * frac, 40, e.color, 2.5, true)
		if st == "COMPLETE":
			canvas.draw_circle(e.pos, r + 6, Color(e.color, 0.08))
		if id == recommended and st != "COMPLETE":
			canvas.draw_arc(e.pos, r + 9, 0, TAU, 48, Color("f5ce83", 0.9), 1.5, true)

func _link(a: String, b: String) -> void:
	var na: Dictionary = nodes[a]
	var done_a: bool = states.get(a) == "COMPLETE"
	var done_b: bool = states.get(b) == "COMPLETE"
	var hidden: bool = na.node.tier > unlocked_tier
	var col: Color = na.color
	var c := Color(col, 0.9) if done_a and done_b else (Color(col, 0.45) if done_a or done_b else Color(DIM, 1.0))
	if hidden:
		c = Color(DIM, 0.4)
	canvas.draw_line(na.pos, nodes[b].pos, c, 2.5 if done_a and done_b else 1.5, true)

func _link_pos(a: Vector2, b: Vector2, done: bool, col: Color, hidden: bool) -> void:
	canvas.draw_line(a, b, Color(DIM, 0.4) if hidden else (Color(col, 0.7) if done else Color(DIM, 1.0)), 2.0 if done else 1.5, true)

# ---------- camera ----------
func _input_view(e: InputEvent) -> void:
	if e is InputEventMouseButton:
		if e.button_index == MOUSE_BUTTON_WHEEL_UP and e.pressed:
			_zoom_at(e.position, 1.12)
		elif e.button_index == MOUSE_BUTTON_WHEEL_DOWN and e.pressed:
			_zoom_at(e.position, 1 / 1.12)
		elif e.button_index == MOUSE_BUTTON_LEFT:
			dragging = e.pressed
	elif e is InputEventMouseMotion and dragging:
		if motion and motion.is_valid():
			motion.kill()
		canvas.position += e.relative
		_clamp()

func _zoom_at(at: Vector2, factor: float) -> void:
	var before := (at - canvas.position) / zoom
	_set_zoom(clampf(zoom * factor, 0.42, 1.6))
	canvas.position = at - before * zoom
	_clamp()

func _set_zoom(z: float) -> void:
	zoom = z
	canvas.scale = Vector2(zoom, zoom)
	for id in nodes:
		nodes[id].lbl.visible = nodes[id].node.tier <= unlocked_tier and zoom >= 0.75

func zoom_by(factor: float) -> void:
	_zoom_at(size / 2, factor)

func _clamp() -> void:
	var extent := WORLD * zoom
	canvas.position.x = clampf(canvas.position.x, minf(0.0, size.x - extent.x - 40), 40)
	canvas.position.y = clampf(canvas.position.y, minf(0.0, size.y - extent.y - 40), 40)

func focus_point(world: Vector2, animate := true) -> void:
	var target := size / 2 - world * zoom
	target.x = clampf(target.x, minf(0.0, size.x - WORLD.x * zoom - 40), 40)
	target.y = clampf(target.y, minf(0.0, size.y - WORLD.y * zoom - 40), 40)
	if motion and motion.is_valid():
		motion.kill()
	if not animate or reduced or not is_inside_tree():
		canvas.position = target
		return
	motion = create_tween()
	motion.tween_property(canvas, "position", target, 0.35).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)

func focus(id: String, animate := true) -> void:
	if nodes.has(id):
		focus_point(nodes[id].pos, animate)

func focus_tier(tier: int, animate := true) -> void:
	match tier:
		1: focus_point(Vector2(300, 330), animate)
		2: focus_point(HUB + Vector2(0, -120), animate)
		_: focus_point(OBSERVATORY, animate)
