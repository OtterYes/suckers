extends Control
## Living night sky behind the whole UI. Grows brighter and denser as the Night Atlas fills in;
## crowned Archive constellations leave nebula glows behind.
var density := 0.0          # 0..1  (claimed stars / 96)
var nebulae: Array = []     # [{pos: Vector2 (0..1), color: Color}]
var reduced := false
var time := 0.0
var points: PackedVector2Array = []
var seeds: PackedFloat32Array = []

func _ready() -> void:
	mouse_filter = MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(PRESET_FULL_RECT)
	var rng := RandomNumberGenerator.new()
	rng.seed = 2026
	for i in 420:
		points.append(Vector2(rng.randf(), rng.randf()))
		seeds.append(rng.randf() * TAU)
	resized.connect(queue_redraw)

func _process(delta: float) -> void:
	if reduced:
		return
	time += delta
	queue_redraw()

func _draw() -> void:
	var count := int(90 + density * 330)
	for n in nebulae:
		var c: Vector2 = n.pos * size
		for r in [260.0, 170.0, 90.0]:
			draw_circle(c, r, Color(n.color, 0.035))
	for i in count:
		var p: Vector2 = points[i] * size
		var tw := 0.55 + 0.45 * sin(time * (0.6 + fmod(seeds[i], 1.4)) + seeds[i])
		var big := i % 23 == 0
		var col := Color("f5ce83") if i % 11 == 0 else (Color("75e3d3") if i % 7 == 0 else Color("dbe6f5"))
		draw_circle(p, 1.6 if big else 1.0, Color(col, (0.25 + 0.5 * density) * tw))
