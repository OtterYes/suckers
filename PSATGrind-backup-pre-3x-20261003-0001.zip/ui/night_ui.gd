extends RefCounted
## Night School shell: rail navigation, header, living starfield, the Night Atlas sky, goal tracker and reveals.
const MapView=preload("res://ui/atlas_map.gd")
const CoreView=preload("res://ui/study_core.gd")
const Starfield=preload("res://ui/starfield.gd")
var g
var rail: VBoxContainer
var mobile_nav: HFlowContainer
var body: BoxContainer
var content: VBoxContainer
var workshop: VBoxContainer
var core
var core_label: Label
var quick_buttons: Dictionary={}
var tracker: VBoxContainer
var goal_slots: Array=[]
var current_screen:="home"
var atlas_body: VBoxContainer
var atlas_header: Label
var atlas_map
var detail: VBoxContainer
var tier_buttons: Array[Button]=[]
var chapter_index:=0
var selected_tier:=1
var selected_path:="precision"
var selected_node:="f01"
var map_signature:=""
var trial_status:Label
var skill_grid:GridContainer
var upgrade_row:BoxContainer
var workshop_timer:=0.0
var reveal:Control
var pending:Array=[]
var preferences:AcceptDialog
var automation_box:VBoxContainer
var exchange_btn:Button
var title:Label
var rank_lbl:Label
var rail_rank:Label
var home_rank:Label
var home_sub:Label
var core_time:=-1000.0
var atlas_split:BoxContainer
var goals_box:BoxContainer
var trials_box:VBoxContainer
var trial_buttons:Dictionary={}
var end_trial_button:Button
var starfield:Control
var focus_next:Button

func _init(game)->void:
	g=game

func column(parent:Node,gap:=10)->VBoxContainer:
	var box:=VBoxContainer.new()
	box.add_theme_constant_override("separation",gap)
	box.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	parent.add_child(box)
	return box

func row(parent:Node,gap:=10)->HBoxContainer:
	var box:=HBoxContainer.new()
	box.add_theme_constant_override("separation",gap)
	parent.add_child(box)
	return box

func label(parent:Node,text:String,font_size:=16,color:=Color("eef3fb"))->Label:
	var item:Label=g._label(parent,text,font_size,color)
	item.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	item.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	return item

func card(parent:Node)->VBoxContainer:
	var panel:=PanelContainer.new()
	panel.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	parent.add_child(panel)
	return column(panel)

func button(parent:Node,text:String,action:Callable)->Button:
	var b:Button=g._button(parent,text,action)
	b.add_theme_font_size_override("font_size",14)
	b.custom_minimum_size.y=38
	b.custom_minimum_size.x=44 if text in ["←","→","−","+"] else minf(210,maxf(92,text.length()*6.5+28))
	b.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	return b

func clear(parent:Node)->void:
	for child in parent.get_children():
		parent.remove_child(child)
		child.queue_free()

func reduced()->bool:
	return g.s.get("atlas",{}).get("reduced_motion",false)

func build()->void:
	g.theme=g._make_theme()
	var bg:=ColorRect.new()
	bg.color=g.C_BG
	bg.mouse_filter=Control.MOUSE_FILTER_IGNORE
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	g.add_child(bg)
	starfield=Starfield.new()
	g.add_child(starfield)
	var margin:=MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left","right","top","bottom"]: margin.add_theme_constant_override("margin_"+side,18)
	g.add_child(margin)
	var shell:=row(margin,18)
	rail=column(shell,12)
	rail.custom_minimum_size.x=146
	rail.size_flags_horizontal=Control.SIZE_FILL
	label(rail,"PSAT\nGRIND.",28,g.C_CYAN)
	label(rail,"N I G H T   S C H O O L",10,g.C_MUTED)
	for key in ["home","study","skills","upgrades","atlas","psat"]:
		var b:=button(rail,"Night Atlas" if key=="atlas" else key.capitalize(),g._show.bind(key))
		g.nav_btns[key]=b
	var spacer:=Control.new()
	spacer.size_flags_vertical=Control.SIZE_EXPAND_FILL
	rail.add_child(spacer)
	rail_rank=label(rail,"",13,g.C_GOLD)
	label(rail,"Small answers.\nDistant stars.",14,g.C_MUTED)
	button(rail,"Preferences",_settings)
	var main:=column(shell,12)
	main.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	mobile_nav=HFlowContainer.new()
	main.add_child(mobile_nav)
	for key in ["home","study","skills","upgrades","atlas","psat"]:
		button(mobile_nav,"Atlas" if key=="atlas" else key.capitalize(),g._show.bind(key))
	button(mobile_nav,"Settings",_settings)
	var head:=row(main)
	var heading:=column(head,2)
	title=label(heading,"Your night, your next breakthrough.",23,g.C_TEXT)
	label(heading,"Learn something. Build something. Go a little further.",12,g.C_MUTED)
	var wallet:=column(head,2)
	wallet.size_flags_horizontal=Control.SIZE_FILL
	wallet.custom_minimum_size.x=190
	g.kp_lbl=label(wallet,"0 KP",30,g.C_GOLD)
	g.kp_lbl.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT
	g.rate_lbl=label(wallet,"",12,g.C_MUTED)
	g.rate_lbl.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT
	rank_lbl=label(wallet,"",12,g.C_CYAN)
	rank_lbl.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT
	var chips:=HFlowContainer.new()
	chips.add_theme_constant_override("h_separation",10)
	main.add_child(chips)
	g.streak_lbl=label(chips,"",12,g.C_CYAN)
	g.scholar_lbl=label(chips,"",12,g.C_MUTED)
	g.best_lbl=label(chips,"",12,g.C_MUTED)
	g.event_chip=label(chips,"",12,g.C_GOLD)
	body=BoxContainer.new()
	body.add_theme_constant_override("separation",14)
	body.size_flags_vertical=Control.SIZE_EXPAND_FILL
	main.add_child(body)
	content=column(body,10)
	content.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	for key in ["home","study","skills","upgrades","atlas","psat"]:
		var scroll:=ScrollContainer.new()
		scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED
		scroll.size_flags_vertical=Control.SIZE_EXPAND_FILL
		scroll.size_flags_horizontal=Control.SIZE_EXPAND_FILL
		content.add_child(scroll)
		g.screens[key]=scroll
		var inner:=column(scroll,12)
		match key:
			"home":_home(inner)
			"study":g._build_study(inner)
			"skills":
				var box:Control=g._build_skills(inner)
				skill_grid=box.get_child(1)
				var review:=button(inner,"Review Desk · focus missed questions",func():
					if not g.atlas.claimed("f12"):g._toast("Unlock Return to Errors in Night Atlas first.");return
					g.atlas.data().review=not g.atlas.data().review
					g._toast("Review Desk enabled" if g.atlas.data().review else "Review Desk disabled")
					g._next_question();g._show("study");g._save())
				review.tooltip_text="Unlock at Foundation step 12. Prioritizes questions you previously missed; falls back to normal study when none remain."
			"upgrades":
				label(inner,"Three columns, one rule: the deeper upgrades in each column reveal themselves once the one above reaches Lv 2. ★ marks the recommended next buy.",12,g.C_MUTED)
				upgrade_row=g._build_upgrades(inner)
			"atlas":_build_atlas(inner)
			"psat":
				g._build_psat(inner)
				label(inner,"Game score only — not an official PSAT score prediction. Night Atlas, Insight and its permanent rewards survive prestige.",12,g.C_MUTED)
	workshop=column(body,10)
	workshop.custom_minimum_size.x=266
	workshop.size_flags_horizontal=Control.SIZE_FILL
	var lab:=card(workshop)
	label(lab,"THE STUDY CORE",11,g.C_CYAN)
	core=CoreView.new()
	lab.add_child(core)
	core.clicked.connect(_core_click)
	core_label=label(lab,"",12,g.C_MUTED)
	label(workshop,"Your next advantage",17,g.C_TEXT)
	for id in ["flash","group","mnem"]:
		var upgrade:Dictionary=g.UPGRADES.filter(func(u):return u.id==id)[0]
		var b:=button(workshop,"",g._buy.bind(upgrade))
		b.tooltip_text=upgrade.desc
		quick_buttons[id]=b
	button(workshop,"All upgrades →",g._show.bind("upgrades"))
	tracker=column(main,4)
	goals_box=BoxContainer.new()
	goals_box.add_theme_constant_override("separation",8)
	tracker.add_child(goals_box)
	for i in 3:
		var panel:=PanelContainer.new()
		panel.size_flags_horizontal=Control.SIZE_EXPAND_FILL
		panel.add_theme_stylebox_override("panel",g._sb(g.C_PANEL,g.C_BORDER,10,1,12,6))
		panel.mouse_default_cursor_shape=Control.CURSOR_POINTING_HAND
		goals_box.add_child(panel)
		var v:=column(panel,2)
		var cap:=label(v,["NOW","NEXT UNLOCK","DISTANT HORIZON"][i],10,[g.C_CYAN,g.C_GOLD,g.C_MUTED][i])
		var t:=label(v,"",12,g.C_TEXT)
		t.text_overrun_behavior=TextServer.OVERRUN_TRIM_ELLIPSIS
		t.autowrap_mode=TextServer.AUTOWRAP_OFF
		var bar:=ProgressBar.new()
		bar.show_percentage=false
		bar.custom_minimum_size.y=4
		bar.max_value=1.0
		v.add_child(bar)
		panel.gui_input.connect(func(e):
			if e is InputEventMouseButton and e.pressed and e.button_index==MOUSE_BUTTON_LEFT:
				var id:String=panel.get_meta("goal","")
				if id!="" and g.atlas.by_id.has(id):_open_node(id)
				else:g._show("atlas"))
		goal_slots.append({"panel":panel,"cap":cap,"title":t,"bar":bar})
	g.toast=label(main,"",12,g.C_GOLD)
	g.toast.custom_minimum_size.y=18
	g.resized.connect(responsive)
	responsive()

func _home(parent:Node)->void:
	var intro:=card(parent)
	label(intro,"THE NIGHT ATLAS",12,g.C_CYAN)
	home_rank=label(intro,"",32,g.C_TEXT)
	home_sub=label(intro,"",15,g.C_MUTED)
	var actions:=HFlowContainer.new()
	actions.add_theme_constant_override("h_separation",10)
	intro.add_child(actions)
	button(actions,"Continue studying →",g._show.bind("study"))
	button(actions,"Open the Night Atlas →",g._show.bind("atlas"))
	var stages:=card(parent)
	label(stages,"One close goal. One distant horizon.",20,g.C_TEXT)
	label(stages,"I · Lanterns — 24 short chapters of practice and discovery.\nII · Disciplines — 36 steps across The Lens, The Bridge and The Engine.\nIII · Night Archive — 36 milestones across six distant constellations.",15,g.C_MUTED)
	label(stages,"Your existing skills, trophies and PSAT prestige all feed the journey. No progress reset is required to begin.",13,g.C_CYAN)

func _build_atlas(parent:Node)->void:
	atlas_body=column(parent,10)
	atlas_header=label(atlas_body,"",21,g.C_TEXT)
	var tiers:=HFlowContainer.new()
	tiers.add_theme_constant_override("h_separation",8)
	atlas_body.add_child(tiers)
	for i in 3:
		var b:=button(tiers,["I · Lanterns","II · Disciplines","III · Archive"][i],func():selected_tier=i+1;atlas_map.focus_tier(i+1))
		tier_buttons.append(b)
	focus_next=button(tiers,"★ Find next goal",func():
		var ids:Array=g.atlas.recommendations()
		if ids.size()>0:_open_node(ids[0]))
	button(tiers,"−",func():atlas_map.zoom_by(1/1.25))
	button(tiers,"+",func():atlas_map.zoom_by(1.25))
	label(atlas_body,"Drag to pan · scroll to zoom · click a star for details",11,g.C_MUTED)
	atlas_split=BoxContainer.new()
	atlas_split.add_theme_constant_override("separation",14)
	atlas_split.size_flags_vertical=Control.SIZE_EXPAND_FILL
	atlas_body.add_child(atlas_split)
	atlas_map=MapView.new()
	atlas_map.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	atlas_map.custom_minimum_size=Vector2(300,430)
	atlas_split.add_child(atlas_map)
	atlas_map.setup(g.atlas)
	atlas_map.selected.connect(func(id):selected_node=id;g.atlas.data().new_nodes.erase(id);map_signature="";_draw_atlas())
	detail=card(atlas_split)
	detail.get_parent().custom_minimum_size.x=310
	var trials:=card(atlas_body)
	trials_box=trials
	label(trials,"Observatory trials",19,g.C_TEXT)
	trial_status=label(trials,"",13,g.C_MUTED)
	var actions:=HFlowContainer.new()
	trials.add_child(actions)
	for kind in ["precision","breadth","endurance"]:
		trial_buttons[kind]=button(actions,kind.capitalize(),func():
			if not g.atlas.start_trial(kind):g._toast("Trial unavailable. Read the requirements above."))
		trial_buttons[kind].tooltip_text={"precision":"10 Hard correct, at most 2 errors. Requires Lens 6 or Foundation 24, and unlocked Hard questions.","breadth":"16 correct across all 8 skills, at most 4 errors. Requires all skills Lv 2 and Foundation 12.","endurance":"25 correct, at most 5 errors. Requires Foundation 12."}[kind]
	end_trial_button=button(actions,"End current trial",func():g.atlas.active_trial={};g.atlas.last_trial_message="Trial ended; your KP is safe.";g._save())
	automation_box=card(atlas_body)
	label(automation_box,"Research & workshop",19,g.C_TEXT)
	exchange_btn=button(automation_box,"",func():
		if g.atlas.exchange():g._toast("Research complete · Insight earned");map_signature="")
	for entry in [["auto_buy","a03","Auto-buy selected upgrade (keep 50% KP)"],["auto_claim","a09","Auto-claim completed Foundation steps"],["auto_convert","a12","Auto-convert study credits (keep 50% KP)"]]:
		var check:=CheckButton.new()
		check.text=entry[2]
		check.add_theme_font_size_override("font_size",13)
		check.set_meta("setting",entry[0]);check.set_meta("unlock",entry[1])
		check.toggled.connect(func(value):g.atlas.data()[entry[0]]=value;g._save())
		automation_box.add_child(check)
	var picker:=OptionButton.new()
	for upgrade in g.UPGRADES:picker.add_item(upgrade.name)
	picker.item_selected.connect(func(index):g.atlas.data().selected_buy=g.UPGRADES[index].id;g._save())
	picker.set_meta("upgrade_picker",true)
	automation_box.add_child(picker)

func _draw_atlas()->void:
	if not is_instance_valid(atlas_map):return
	var a=g.atlas
	var tier:int=a.unlocked_tier()
	atlas_header.text="Night Atlas · %d / 96 stars · %d Insight · %s" % [a.data().claimed.size(),a.data().insight,a.rank_title()]
	var recs:Array=a.recommendations()
	var states:Dictionary={}
	var progress:Dictionary={}
	for node in a.nodes:
		states[node.id]=a.state_of(node)
		progress[node.id]=a.progress(node)
	var signature:String=str([selected_node,states,a.data().insight,a.data().path,a.data().pins,recs,progress.values().map(func(v):return int(v*50))])
	if signature==map_signature:return
	map_signature=signature
	atlas_map.reduced=reduced()
	atlas_map.refresh(states,progress,selected_node,tier,recs[0] if recs.size()>0 else "")
	clear(detail)
	var node:Dictionary=a.by_id[selected_node]
	var state:String=states[selected_node]
	if node.tier>tier:
		label(detail,node.title,20,g.C_TEXT)
		label(detail,"A distant sky is waiting.",16,g.C_CYAN)
		label(detail,"Complete 18 Foundation steps to unlock three disciplines." if node.tier==2 else "Complete all 24 Foundation steps, 24 specialization steps (at least 6 in each path), 3 trials and 5 PSAT prestiges.",13,g.C_MUTED)
		var tb:=ProgressBar.new()
		tb.show_percentage=false
		tb.custom_minimum_size.y=6
		tb.value=a.tier_progress(node.tier)*100
		detail.add_child(tb)
		label(detail,"Reward when reached: "+node.reward,12,g.C_MUTED)
		button(detail,"Unpin" if node.id in a.data().pins else "Pin as a far goal",func():a.pin(node.id);map_signature="";_draw_atlas())
		return
	var state_color:Color={"COMPLETE":g.C_CYAN,"CLAIM":g.C_GOLD,"NEED INSIGHT":g.C_GOLD,"NEARLY THERE":g.C_CYAN}.get(state,g.C_MUTED)
	var head:=row(detail,8)
	label(head,node.title,20,g.C_TEXT)
	var chip:Label=g._chip(head,state_color)
	chip.text=state
	chip.add_theme_font_size_override("font_size",11)
	label(detail,node.reward,14,g.C_CYAN)
	for key in node.req:
		var met:bool=a.metric(key)>=node.req[key]
		label(detail,("✓ " if met else "○ ")+a.requirement_name(key)+": "+g.fmt(a.metric(key))+" / "+g.fmt(node.req[key]),13,g.C_CYAN if met else g.C_MUTED)
	var bar:=ProgressBar.new()
	bar.show_percentage=false
	bar.custom_minimum_size.y=6
	bar.value=a.progress(node)*100
	detail.add_child(bar)
	var actions:=HFlowContainer.new()
	actions.add_theme_constant_override("h_separation",8)
	detail.add_child(actions)
	var claim:=button(actions,"Completed" if a.claimed(node.id) else ("Claim · free" if node.price==0 else "Inscribe · %d Insight" % node.price),func():
		if a.claim(node.id):core.pulse();map_signature="";_draw_atlas();_check_reveal())
	claim.disabled=not a.ready(node) or a.data().insight<node.price
	if state=="CLAIM":claim.add_theme_stylebox_override("normal",g._sb(g.C_GOLD.darkened(.6),g.C_GOLD))
	if not a.prerequisites(node) and not a.claimed(node.id):claim.tooltip_text="Finish the previous star and unlock this tier first."
	if not a.claimed(node.id):button(actions,"Unpin" if node.id in a.data().pins else "Pin goal",func():a.pin(node.id);map_signature="";_draw_atlas())
	if node.tier==2:
		var activate:=button(detail,"Active discipline" if a.data().path==node.path else "Activate "+a.PATH_NAMES[node.path],func():a.data().path=node.path;g._save();map_signature="";_draw_atlas())
		activate.disabled=a.data().path==node.path
		label(detail,"Switch freely. Only the active discipline grants its answer bonus; permanent unlocks remain available.",12,g.C_MUTED)

func _open_node(id:String)->void:
	var node:Dictionary=g.atlas.by_id[id]
	selected_tier=node.tier
	selected_path=node.path if node.path!="" else "precision"
	chapter_index=node.chapter
	selected_node=id
	map_signature=""
	g._show("atlas")
	atlas_map.focus(id)

## Called by the atlas when a star is claimed: light it up on the map, crown chapters get a reveal.
func on_claim(node:Dictionary)->void:
	map_signature=""
	if is_instance_valid(atlas_map) and atlas_map.is_visible_in_tree() and atlas_map.nodes.has(node.id):
		var e:Dictionary=atlas_map.nodes[node.id]
		g._spark_burst(e.btn.global_position+e.btn.size/2)
	else:
		g._spark_burst(g.kp_lbl.global_position+g.kp_lbl.size/2)
	if node.tier==3 and (int(node.id.substr(1))-1)%6==5 and not node.id in g.atlas.data().crowns_seen:
		g.atlas.data().crowns_seen.append(node.id)
		celebrate(g.atlas.CHAPTERS[node.chapter].to_upper()+" · CROWNED","%s\n\nThe constellation glows in the night sky. %d / 6 crowns." % [node.reward,g.atlas.end_count(5)],atlas_map.ARCHIVE_COLORS[node.chapter])
	elif node.id=="f24":
		celebrate("FOUNDATION COMPLETE","All 24 lanterns are lit. Every trial is open and the Study Core has become an observatory.",g.C_CYAN)

func tracker_goals()->Array:
	var a=g.atlas
	var recs:Array=a.recommendations()
	var pins:Array=a.data().pins
	var out:Array=[]
	if recs.size()>0:
		var n:Dictionary=a.by_id[recs[0]]
		out.append({"cap":"PINNED" if recs[0] in pins else "NOW","title":"%s · %s" % [n.title,a.state_of(n)],"frac":1.0 if a.claimed(n.id) else a.progress(n),"id":recs[0]})
	else:out.append({"cap":"NOW","title":"Every star charted","frac":1.0,"id":""})
	var tier:int=a.unlocked_tier()
	if pins.size()>=2:
		var n:Dictionary=a.by_id[pins[1]]
		out.append({"cap":"PINNED","title":"%s · %d%%" % [n.title,int(a.progress(n)*100)],"frac":a.progress(n),"id":pins[1]})
	elif tier==1 and a.count(1)<12:out.append({"cap":"NEXT UNLOCK","title":"First trial · %d / 12 lanterns" % a.count(1),"frac":a.count(1)/12.0,"id":""})
	elif tier==1:out.append({"cap":"NEXT UNLOCK","title":"Tier II · The Disciplines · %d / 18 lanterns" % a.count(1),"frac":a.tier_progress(2),"id":""})
	elif tier==2:out.append({"cap":"NEXT UNLOCK","title":"Tier III · The Night Archive · %d%%" % int(a.tier_progress(3)*100),"frac":a.tier_progress(3),"id":""})
	else:
		var crown:=""
		for c in 6:
			if not a.claimed("e%02d" % (c*6+6)):crown="e%02d" % (c*6+6);break
		if crown=="":out.append({"cap":"NEXT UNLOCK","title":"All six crowns claimed","frac":1.0,"id":""})
		else:
			var n:Dictionary=a.by_id[crown]
			out.append({"cap":"NEXT CROWN","title":"%s · %d%%" % [n.title,int(a.progress(n)*100)],"frac":a.progress(n),"id":crown})
	if pins.size()>=3:
		var n:Dictionary=a.by_id[pins[2]]
		out.append({"cap":"PINNED","title":"%s · %d%%" % [n.title,int(a.progress(n)*100)],"frac":a.progress(n),"id":pins[2]})
	elif tier==1:out.append({"cap":"DISTANT HORIZON","title":"Light all 24 lanterns · %d / 24" % a.count(1),"frac":a.count(1)/24.0,"id":""})
	elif tier==2:out.append({"cap":"DISTANT HORIZON","title":"Inscribe all 36 disciplines · %d / 36" % a.count(2),"frac":a.count(2)/36.0,"id":""})
	else:out.append({"cap":"DISTANT HORIZON","title":"Keeper of the Night · %d / 96 stars" % a.data().claimed.size(),"frac":a.data().claimed.size()/96.0,"id":""})
	return out

func refresh(delta:float)->void:
	if g.s.is_empty() or not g.s.has("atlas"):return
	var a=g.atlas
	var goals:Array=tracker_goals()
	for i in goal_slots.size():
		var slot:Dictionary=goal_slots[i]
		var goal:Dictionary=goals[i]
		slot.cap.text=goal.cap
		slot.title.text=goal.title
		g._progress_to(slot.bar,goal.frac)
		slot.panel.set_meta("goal",goal.id)
		slot.panel.tooltip_text=(a.by_id[goal.id].reward if goal.id!="" else "Open the Night Atlas")
	var rank:String=a.rank_title()
	var nxt:Array=a.next_rank()
	rank_lbl.text=rank
	rail_rank.text=rank+"\n%d / 96 stars" % a.data().claimed.size()
	home_rank.text=rank
	home_sub.text="%d / 96 stars charted · %d Insight · next rank: %s at %d stars" % [a.data().claimed.size(),a.data().insight,nxt[1],nxt[0]] if a.data().claimed.size()<96 else "Every star charted. The night is yours."
	starfield.reduced=reduced()
	starfield.density=a.data().claimed.size()/96.0
	var nebulae:Array=[]
	for c in 6:
		if a.claimed("e%02d" % (c*6+6)):nebulae.append({"pos":Vector2(0.15+0.14*c,0.2+0.5*(c%2)),"color":atlas_map.ARCHIVE_COLORS[c]})
	for p in a.PATHS:
		if a.count(2,p)>=12:nebulae.append({"pos":Vector2(0.5,0.5)+Vector2.from_angle(a.PATHS.find(p)*2.1)*0.3,"color":atlas_map.PATH_COLORS[p]})
	starfield.nebulae=nebulae
	if current_screen=="atlas":
		_draw_atlas()
		trials_box.get_parent().visible=a.count(1)>=10
		trial_status.text="Focused challenges award Insight. Hover a trial for its rules. Your KP is safe if you fail." if a.count(1)>=12 else "Complete Return to Errors (Foundation 12) to open your first trial."
		for kind in trial_buttons:trial_buttons[kind].disabled=not a.can_start_trial(kind)
		end_trial_button.visible=not a.active_trial.is_empty()
		if not a.active_trial.is_empty():trial_status.text="%s trial · %d / %d correct · %d / %d errors" % [a.active_trial.kind.capitalize(),a.active_trial.correct,a.active_trial.target,a.active_trial.errors,a.active_trial.allowed]
		elif a.last_trial_message!="":trial_status.text=a.last_trial_message+"\n"+trial_status.text
		automation_box.get_parent().visible=a.claimed("s03") or a.claimed("a03")
		exchange_btn.text="Research Exchange · %s KP → %d Insight · %d study credits" % [g.fmt(a.conversion_cost()),2 if a.claimed("s12") else 1,a.conversion_credits()]
		exchange_btn.disabled=not a.claimed("s03") or a.conversion_credits()<1 or g.s.kp<a.conversion_cost()
		for item in automation_box.get_children():
			if item is CheckButton:
				item.visible=a.claimed(item.get_meta("unlock"))
				item.set_pressed_no_signal(a.data()[item.get_meta("setting")])
			if item is OptionButton:
				item.visible=a.claimed("a03")
				for i in g.UPGRADES.size():
					if g.UPGRADES[i].id==a.data().selected_buy:item.select(i)
	core.rank=a.unlocked_tier()-1 + int(a.claimed("f16"))
	core.crew=mini(6,g.lvl("group"))
	core.reduced=reduced()
	core.queue_redraw()
	core_label.text="%d / %d charge · +%d KP per click\n%d study groups · %d prestige scholars" % [a.data().core_charge,a.core_capacity(),1+int(a.perk("core_kp")),g.lvl("group"),g.s.scholars]
	for id in quick_buttons:
		var u:Dictionary=g.UPGRADES.filter(func(up):return up.id==id)[0]
		var price:float=g.cost(u)
		var b:Button=quick_buttons[id]
		b.text="%s · Lv %d\n%s KP" % [u.name,g.lvl(id),g.fmt(ceil(price))]
		b.disabled=g.s.kp<price
		b.add_theme_color_override("font_color",g.C_CYAN)
	workshop_timer+=delta
	if workshop_timer>=2:
		workshop_timer=0
		if g._passive_rate()>0:core.pulse()
	_check_reveal()
	if not is_instance_valid(reveal) and pending.size()>0:_show_celebration(pending.pop_front())

func _check_reveal()->void:
	var tier:int=g.atlas.unlocked_tier()
	if tier<=g.atlas.data().seen_tier or is_instance_valid(preferences):return
	g.atlas.data().seen_tier=tier
	g._save()
	if tier==2:celebrate("TIER II · THE DISCIPLINES","Three constellations rise from the hub: The Lens, The Bridge and The Engine.\nChoose one to walk first. 36 permanent goals and a new way to study.",atlas_map.PATH_COLORS.synthesis)
	else:celebrate("TIER III · THE NIGHT ARCHIVE","Six distant constellations ring the Observatory. 36 milestones, six crowns.\nYour observatory is only the beginning.",g.C_GOLD)

## Full-screen reveal: dims the room, bursts light from the centre, names the moment.
func celebrate(heading:String,body_text:String,color:Color)->void:
	if is_instance_valid(reveal):
		pending.append([heading,body_text,color])
		return
	_show_celebration([heading,body_text,color])

func _show_celebration(item:Array)->void:
	var overlay:=Control.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter=Control.MOUSE_FILTER_STOP
	g.add_child(overlay)
	reveal=overlay
	var dim:=ColorRect.new()
	dim.color=Color(g.C_BG,0.0)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(dim)
	var center:=CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(center)
	var panel:=PanelContainer.new()
	panel.add_theme_stylebox_override("panel",g._sb(g.C_PANEL,item[2],16,2,34,28))
	panel.custom_minimum_size.x=minf(560,g.size.x-40)
	center.add_child(panel)
	var v:=column(panel,10)
	var cap:=label(v,"A NEW SKY OPENS",11,item[2])
	cap.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	var h:=label(v,item[0],30,g.C_TEXT)
	h.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	var b:=label(v,item[1],15,g.C_MUTED)
	b.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	var go:=button(v,"Continue",func():overlay.queue_free())
	go.add_theme_stylebox_override("normal",g._sb(item[2].darkened(.6),item[2]))
	go.size_flags_horizontal=Control.SIZE_SHRINK_CENTER
	g._play("trophy")
	if reduced():
		dim.color=Color(g.C_BG,.88)
		return
	panel.pivot_offset=panel.size/2
	panel.scale=Vector2(.9,.9)
	var tw:Tween=g.create_tween().set_parallel()
	tw.tween_property(dim,"color",Color(g.C_BG,.88),.35)
	tw.tween_property(panel,"scale",Vector2.ONE,.35).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	for i in 28:
		var spark:=ColorRect.new()
		spark.color=item[2] if i%3 else g.C_TEXT
		spark.size=Vector2(5,5)
		spark.mouse_filter=Control.MOUSE_FILTER_IGNORE
		overlay.add_child(spark)
		overlay.move_child(spark,1)
		spark.position=g.size/2
		var dist:=randf_range(160,420)
		var t:Tween=g.create_tween().set_parallel()
		t.tween_property(spark,"position",g.size/2+Vector2.from_angle(TAU*i/28+randf()*.2)*dist,.9).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
		t.tween_property(spark,"modulate:a",0.0,.9).set_delay(.3)
		t.chain().tween_callback(spark.queue_free)

func _core_click()->void:
	var now:=Time.get_ticks_msec()/1000.0
	if now-core_time<1.0:return
	if g.atlas.data().core_charge<1:g._toast("Answer correctly to recharge the Study Core.");return
	core_time=now
	g.atlas.data().core_charge-=1
	g.atlas.data().core_clicks+=1
	var amount:int=1+int(g.atlas.perk("core_kp"))
	g._gain(amount)
	core.pulse()
	g._float_at("+%d KP" % amount,core.global_position+Vector2(core.size.x/2,50),g.C_GOLD)
	g._save()

func show_screen(name:String)->void:
	for effect in g.get_tree().get_nodes_in_group("reward_fx"):effect.queue_free()
	current_screen=name
	workshop.visible=name in ["home","study"] and g.size.x>=1050
	title.text={"home":"A whole sky to work toward.","study":"One question closer.","skills":"Build your range.","upgrades":"Make the grind work for you.","atlas":"The Night Atlas","psat":"Carry your knowledge forward."}.get(name,name)
	if name=="atlas":
		if not g.atlas.by_id.has(selected_node) or g.atlas.claimed(selected_node):
			var ids:Array=g.atlas.recommendations()
			if ids.size()>0:selected_node=ids[0]
		_draw_atlas()
		atlas_map.focus(selected_node,false)
	if not reduced():
		g.screens[name].modulate.a=.6
		g.create_tween().tween_property(g.screens[name],"modulate:a",1.0,.12)
	responsive()

func responsive()->void:
	if not is_instance_valid(rail):return
	rail.visible=g.size.x>=1050
	mobile_nav.visible=not rail.visible
	if g.size.x<1050:
		var study_content:Node=g.screens.study.get_child(0)
		if workshop.get_parent()!=study_content:workshop.reparent(study_content)
		workshop.custom_minimum_size.x=0
		workshop.size_flags_horizontal=Control.SIZE_EXPAND_FILL
		workshop.visible=current_screen=="study"
	else:
		if workshop.get_parent()!=body:workshop.reparent(body)
		workshop.custom_minimum_size.x=266
		workshop.size_flags_horizontal=Control.SIZE_FILL
		workshop.visible=current_screen in ["home","study"]
	skill_grid.columns=3 if g.size.x>=1050 else (2 if g.size.x>=700 else 1)
	upgrade_row.vertical=g.size.x<900
	atlas_split.vertical=g.size.x<850
	goals_box.vertical=g.size.x<700
	if is_instance_valid(g.qtext):g.qtext.get_parent().get_child(0).vertical=g.size.x<780
	if is_instance_valid(g.hint_btn):g.hint_btn.get_parent().vertical=g.size.x<780
	tracker.visible=g.size.y>=540

func _settings()->void:
	if is_instance_valid(preferences):preferences.popup_centered();return
	preferences=AcceptDialog.new()
	preferences.title="Night School preferences"
	preferences.min_size=Vector2i(360,190)
	var box:=VBoxContainer.new()
	preferences.add_child(box)
	for entry in [["Reduced motion",true],["Mute sound",false]]:
		var check:=CheckButton.new()
		check.text=entry[0]
		check.button_pressed=g.atlas.data().reduced_motion if entry[1] else g.s.muted
		check.toggled.connect(func(value):
			if entry[1]:g.atlas.data().reduced_motion=value
			else:g.s.muted=value
			g._save())
		box.add_child(check)
	g.add_child(preferences)
	preferences.confirmed.connect(preferences.queue_free)
	preferences.canceled.connect(preferences.queue_free)
	preferences.popup_centered()
