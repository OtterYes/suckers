extends Control
const Atlas = preload("res://systems/night_atlas.gd")
const NightUI = preload("res://ui/night_ui.gd")
var atlas
var ui
var test_mode := false
var refresh_elapsed := 0.0
var automation_elapsed := 0.0
var hint_used := false
var offline_gained := 0.0
var last_feedback := ""
# PSAT Grind: pick a skill -> answer questions -> earn Knowledge Points (KP) -> buy upgrades -> prestige by taking the PSAT.
# Screens: STUDY / SKILLS / UPGRADES / PSAT (Tab cycles). Self-check:  godot --headless --path . -- --selftest

const SAVE_PATH := "user://save.json"
const TIERS := ["EASY", "MEDIUM", "HARD"]
const GROUPS := ["TOOLS", "PASSIVE", "MASTERY"]
const SEC_NAMES := {"Math": "Math", "RW": "Reading & Writing"}
const SKILLS := [
	{"id": "alg", "name": "Algebra", "sec": "Math"},
	{"id": "adv", "name": "Advanced Math", "sec": "Math"},
	{"id": "psd", "name": "Problem Solving & Data", "sec": "Math"},
	{"id": "geo", "name": "Geometry & Trig", "sec": "Math"},
	{"id": "craft", "name": "Craft & Structure", "sec": "RW"},
	{"id": "info", "name": "Information & Ideas", "sec": "RW"},
	{"id": "conv", "name": "English Conventions", "sec": "RW"},
	{"id": "expr", "name": "Expression of Ideas", "sec": "RW"},
]
const UPGRADES := [
	{"id": "flash", "grp": 0, "name": "Flashcards", "desc": "+5 KP per correct answer", "base": 25.0, "mult": 1.5},
	{"id": "focus", "grp": 0, "name": "Focus", "desc": "+5% KP per streak step", "base": 150.0, "mult": 1.8},
	{"id": "marker", "grp": 0, "name": "Highlighter", "desc": "+15% KP on Medium, +30% on Hard", "base": 400.0, "mult": 2.2},
	{"id": "sheet", "grp": 0, "name": "Cheat Sheet", "desc": "Hints cost 20% less", "base": 200.0, "mult": 2.0, "max": 4},
	{"id": "group", "grp": 1, "name": "Study Group", "desc": "+1 KP/sec, even while away", "base": 100.0, "mult": 1.6},
	{"id": "tutor", "grp": 1, "name": "Tutor", "desc": "Passive KP x1.25 (compounds)", "base": 1000.0, "mult": 3.0},
	{"id": "caffeine", "grp": 1, "name": "Caffeine", "desc": "Passive KP +2% per streak step", "base": 600.0, "mult": 2.5},
	{"id": "podcast", "grp": 1, "name": "Study Podcast", "desc": "Offline earnings cap +4h", "base": 800.0, "mult": 4.0, "max": 4},
	{"id": "mnem", "grp": 2, "name": "Mnemonics", "desc": "+1 skill XP per correct answer", "base": 300.0, "mult": 2.0},
	{"id": "chance", "grp": 2, "name": "Second Chance", "desc": "Wrong answers keep 25% of streak", "base": 500.0, "mult": 3.0, "max": 3},
	{"id": "mastery", "grp": 2, "name": "Deep Mastery", "desc": "+5% KP per mastery level of the skill", "base": 750.0, "mult": 2.5},
	{"id": "cross", "grp": 2, "name": "Cross-Training", "desc": "+10% KP in Mixed mode", "base": 350.0, "mult": 2.0},
]
# trophies: each one unlocked = permanent +5% KP
const ACHIEVEMENTS := [
	{"id": "first", "name": "First Steps", "desc": "answer a question correctly"},
	{"id": "streak5", "name": "Warming Up", "desc": "reach a 5 streak"},
	{"id": "streak10", "name": "On Fire", "desc": "reach a 10 streak"},
	{"id": "streak25", "name": "Unstoppable", "desc": "reach a 25 streak"},
	{"id": "hard", "name": "Hard Mode", "desc": "answer a Hard question correctly"},
	{"id": "c100", "name": "Century", "desc": "100 lifetime correct answers"},
	{"id": "c500", "name": "Grinder", "desc": "500 lifetime correct answers"},
	{"id": "kp10k", "name": "Ten Thousand", "desc": "earn 10K lifetime KP"},
	{"id": "kp1m", "name": "Millionaire", "desc": "earn 1M lifetime KP"},
	{"id": "lv2", "name": "Rising Star", "desc": "get any skill to Lv 2"},
	{"id": "lv4", "name": "Expert", "desc": "get any skill to Lv 4"},
	{"id": "allup", "name": "Well-Rounded", "desc": "get every skill to Lv 2"},
	{"id": "gear", "name": "Fully Equipped", "desc": "own every upgrade"},
	{"id": "test", "name": "Test Day", "desc": "take the PSAT once"},
	{"id": "s1000", "name": "Four Digits", "desc": "score 1000+"},
	{"id": "s1400", "name": "Merit Scholar", "desc": "score 1400+"},
]
const EVENTS := [
	{"name": "CAFFEINE RUSH", "desc": "2x KP for 45 seconds!"},
	{"name": "LUCKY FIND", "desc": "an old notebook: +%s KP"},
	{"name": "POP QUIZ", "desc": "next correct answer is worth 5x!"},
	{"name": "SECOND WIND", "desc": "+5 streak!"},  # unlocked by the Open the Lens lantern
]
var seen_unlocked: Array = []  # upgrades already shown as unlocked this session

# palette: night-shift study lab
const C_BG := Color("0b1019")
const C_PANEL := Color("161b26")
const C_PANEL2 := Color("1e2533")
const C_BORDER := Color("2b3447")
const C_TEXT := Color("e8ebf3")
const C_MUTED := Color("a6b5ca")
const C_CYAN := Color("75e3d3")
const C_GOLD := Color("f5ce83")
const C_GREEN := Color("4ade80")
const C_RED := Color("f87171")
const C_ORANGE := Color("fb923c")
const TIER_COLORS := [Color("4ade80"), Color("f5ce83"), Color("f87171")]

var questions: Array = []
var s := {}  # all saved state
var q: Dictionary = {}
var last_id := -1
var answered_current := false
var bonus_until := 0.0  # CAFFEINE RUSH end time (seconds)
var pop_quiz := false
var sfx := {}
var player: AudioStreamPlayer
var event_chip: Label
var trophy_lbls := {}

var screens := {}
var nav_btns := {}
var kp_lbl: Label
var rate_lbl: Label
var streak_lbl: Label
var scholar_lbl: Label
var best_lbl: Label
var toast: Label
var skill_lbl: Label
var tier_lbl: Label
var worth_lbl: Label
var qtext: Label
var choice_btns: Array[Button] = []
var explain: Label
var explain_panel: PanelContainer
var hint_btn: Button
var next_btn: Button
var skill_cards := {}  # id -> {bar, info, btn}
var up_btns := {}
var up_bars := {}
var score_lbl: Label
var score_breakdown: Label
var prestige_info: Label
var prestige_btn: Button
var history_lbl: Label


func _ready() -> void:
	atlas = Atlas.new(self)
	test_mode = test_mode or "--test" in OS.get_cmdline_user_args() or "--capture" in OS.get_cmdline_user_args()
	questions = JSON.parse_string(FileAccess.get_file_as_string("res://questions.json"))
	for i in questions.size():
		questions[i]["id"] = i
		questions[i]["diff"] = int(questions[i]["diff"])
		questions[i]["a"] = int(questions[i]["a"])
	if "--selftest" in OS.get_cmdline_user_args():
		set_process(false)
		_selftest()
		get_tree().quit()
		return
	_load()
	_build_sounds()
	_build_ui()
	_next_question()
	_show("home")
	if offline_gained >= 1:
		_toast("Welcome back! Study Group earned %s KP while you were away." % fmt(offline_gained))
	var t := Timer.new()
	t.wait_time = 30
	t.autostart = true
	t.timeout.connect(_save)
	add_child(t)
	if not test_mode: _schedule_event()


func _process(delta: float) -> void:
	var rate := _passive_rate()
	if rate > 0:
		_gain(rate * delta)
	refresh_elapsed += delta
	automation_elapsed += delta
	if automation_elapsed >= 1.0:
		automation_elapsed = 0.0
		atlas.automate()
	if refresh_elapsed >= 0.12:
		_refresh()
		ui.refresh(refresh_elapsed)
		refresh_elapsed = 0.0


func _gain(amount: float) -> void:
	s.kp += amount
	s.run_kp += amount
	s.life_kp += amount


# ---------- fun: random events ----------
func _schedule_event() -> void:
	var sooner: float = clampf(1.0 - atlas.perk("event_rate") / 100.0, 0.4, 1.0) if s.has("atlas") else 1.0
	get_tree().create_timer(randf_range(90.0, 180.0) * sooner).timeout.connect(_fire_event)


func _fire_event() -> void:
	_schedule_event()
	if not screens["study"].visible and not screens["skills"].visible:
		return
	var i := randi() % (4 if atlas.perk("event_new") > 0 else 3)
	var ev: Dictionary = EVENTS[i]
	var desc: String = ev.desc
	match i:
		0:
			bonus_until = Time.get_ticks_msec() / 1000.0 + 45.0
		1:
			var amt: float = maxf(50.0, reward() * 10.0)
			_gain(amt)
			desc = desc % fmt(amt)
		2:
			pop_quiz = true
		3:
			s.streak += 5
	_toast("%s   %s" % [ev.name, desc])
	_float_text(ev.name, C_CYAN)
	_play("event")


func bonus_mult() -> float:
	return 2.0 if Time.get_ticks_msec() / 1000.0 < bonus_until else 1.0


func trophy_mult() -> float:
	return 1.0 + 0.05 * s.ach.size()


func _check_achievements() -> void:
	for a in ACHIEVEMENTS:
		if a.id in s.ach:
			continue
		var ok := false
		match a.id:
			"first": ok = s.life_correct >= 1
			"streak5": ok = s.streak >= 5
			"streak10": ok = s.streak >= 10
			"streak25": ok = s.streak >= 25
			"hard": ok = s.hard_correct >= 1
			"c100": ok = s.life_correct >= 100
			"c500": ok = s.life_correct >= 500
			"kp10k": ok = s.life_kp >= 10000
			"kp1m": ok = s.life_kp >= 1000000
			"lv2": ok = SKILLS.any(func(k): return skill_level(k.id) >= 2)
			"lv4": ok = SKILLS.any(func(k): return skill_level(k.id) >= 4)
			"allup": ok = SKILLS.all(func(k): return skill_level(k.id) >= 2)
			"gear": ok = UPGRADES.all(func(u): return lvl(u.id) >= 1)
			"test": ok = s.tests >= 1
			"s1000": ok = s.best_score >= 1000
			"s1400": ok = s.best_score >= 1400
		if ok:
			s.ach.append(a.id)
			_toast("TROPHY: %s   (+5%% KP forever)" % a.name)
			_float_text("TROPHY: " + a.name, C_GOLD)
			_play("trophy")


# ---------- fun: procedural sounds ----------
func _make_sound(notes: Array, note_len: float, square: bool) -> AudioStreamWAV:
	var rate := 22050
	var data := PackedByteArray()
	for f in notes:
		var n := int(rate * note_len)
		for i in n:
			var v := sin(TAU * f * i / rate)
			if square:
				v = signf(v) * 0.4
			var sample := int(v * (1.0 - float(i) / n) * 11000)
			data.append(sample & 0xFF)
			data.append((sample >> 8) & 0xFF)
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.data = data
	return w


func _build_sounds() -> void:
	sfx["correct"] = _make_sound([660, 880], 0.09, true)
	sfx["wrong"] = _make_sound([200, 150], 0.16, true)
	sfx["buy"] = _make_sound([520, 780], 0.06, true)
	sfx["levelup"] = _make_sound([523, 659, 784, 1047], 0.09, true)
	sfx["trophy"] = _make_sound([784, 988, 1175, 1568], 0.1, false)
	sfx["event"] = _make_sound([440, 660, 880], 0.08, false)
	sfx["click"] = _make_sound([900], 0.03, true)
	player = AudioStreamPlayer.new()
	player.volume_db = -8
	add_child(player)


func _play(name: String) -> void:
	if not player or test_mode or s.get("muted", false):
		return
	player.stream = sfx[name]
	player.play()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST and not s.is_empty():
		_save()


func _unhandled_key_input(e: InputEvent) -> void:
	if not e is InputEventKey or not e.is_pressed() or e.is_echo():
		return
	var k: int = (e as InputEventKey).keycode
	if k == KEY_F2:
		var names := screens.keys()
		for i in names.size():
			if screens[names[i]].visible:
				_show(names[(i + 1) % names.size()])
				return
	if k == KEY_M:
		s.muted = not s.get("muted", false)
		_toast("sound off" if s.muted else "sound on")
		return
	if not screens["study"].visible:
		return
	if k >= KEY_1 and k <= KEY_4 and not answered_current:
		_on_answer(k - KEY_1)
	elif (k == KEY_ENTER or k == KEY_SPACE) and answered_current:
		_next_question()
	elif k == KEY_H and not answered_current:
		_on_hint()


# ---------- numbers ----------
func _default_state() -> Dictionary:
	return {"kp": 0.0, "run_kp": 0.0, "lvls": {}, "streak": 0,
		"sec": {"Math": {"c": 0, "a": 0}, "RW": {"c": 0, "a": 0}},
		"scholars": 0, "best_score": 0, "last_score": 0, "tests": 0,
		"weights": {}, "skills": {}, "mode": "mixed", "saved_at": 0,
		"life_correct": 0, "life_kp": 0.0, "hard_correct": 0, "ach": [], "muted": false}


func lvl(id: String) -> int:
	return int(s.lvls.get(id, 0))


func cost(u: Dictionary) -> float:
	return u.base * pow(u.mult, lvl(u.id))


func scholar_mult() -> float:
	return 1.0 + 0.1 * s.scholars


func _passive_rate() -> float:
	return lvl("group") * pow(1.25, lvl("tutor")) * (1.0 + 0.02 * s.streak * lvl("caffeine")) * scholar_mult() * trophy_mult() * (atlas.passive_multiplier() if s.has("atlas") else 1.0)


func offline_cap_h() -> float:
	return 8.0 + 4.0 * lvl("podcast") + (atlas.perk("offline") if s.has("atlas") else 0.0)


func perk(key: String) -> float:
	return atlas.perk(key) if s.has("atlas") else 0.0


func skill_of(id: String) -> Dictionary:
	for k in SKILLS:
		if k.id == id:
			return k
	return {}


func sk(id: String) -> Dictionary:
	if not s.skills.has(id):
		s.skills[id] = {"xp": 0.0, "c": 0, "a": 0}
	return s.skills[id]


func skill_level(id: String) -> int:
	return int(sqrt(sk(id).xp / 4.0))


func xp_for_level(l: int) -> float:
	return 4.0 * l * l


func skill_tier(id: String) -> int:
	var l := skill_level(id)
	return 1 + int(l >= 2) + int(l >= 4)


func hint_cost() -> float:
	return 50.0 * q.get("diff", 1) * pow(0.8, lvl("sheet")) * (1.0 - perk("hint_discount") / 100.0)


func streak_mult() -> float:
	return 1.0 + min(s.streak, 25 + perk("streak_cap")) * (0.05 + 0.05 * lvl("focus"))


func reward() -> float:
	var d: int = q.diff
	var tier_bonus := 1.0 + 0.15 * (d - 1) * lvl("marker")
	var mastery := 1.0 + skill_level(q.skill) * (0.10 + 0.05 * lvl("mastery"))
	var cross: float = (1.0 + 0.1 * lvl("cross")) if s.mode == "mixed" else 1.0
	var quiz := 5.0 if pop_quiz else 1.0
	return (10.0 + 5.0 * lvl("flash")) * d * tier_bonus * streak_mult() * mastery * cross * scholar_mult() * trophy_mult() * bonus_mult() * quiz * (atlas.kp_multiplier() if s.has("atlas") else 1.0)


func sec_score(key: String) -> int:
	var d: Dictionary = s.sec[key]
	var acc: float = (float(d.c) / d.a) if d.a > 0 else 0.0
	var tiers := 0.0
	var n := 0
	for k in SKILLS:
		if k.sec == key:
			tiers += skill_tier(k.id)
			n += 1
	var factor := 0.5 + 0.25 * (tiers / n - 1.0)
	return 160 + int(600.0 * acc * factor)


func _psat_score() -> int:
	return sec_score("Math") + sec_score("RW")


func run_answered() -> int:
	return int(s.sec.Math.a + s.sec.RW.a)


func _scholars_gain() -> int:
	return int(sqrt(s.run_kp / 500.0) * (1.0 + perk("scholar_pct") / 100.0))


func fmt(v: float) -> String:
	if v >= 1e9: return "%.2fB" % (v / 1e9)
	if v >= 1e6: return "%.2fM" % (v / 1e6)
	if v >= 1e4: return "%.1fK" % (v / 1e3)
	return str(int(v))


# ---------- game ----------
func _next_question() -> void:
	# weighted pick within the chosen skill (or all): missed questions come back more often
	var pool := questions.filter(func(x): return (s.mode == "mixed" or x.skill == s.mode) and x.diff <= skill_tier(x.skill) and x.id != last_id)
	if pool.is_empty():
		pool = questions.filter(func(x): return (s.mode == "mixed" or x.skill == s.mode) and x.diff <= skill_tier(x.skill))
	if not atlas.active_trial.is_empty():
		if atlas.active_trial.kind == "precision":
			var hard_pool: Array = pool.filter(func(x):return x.diff == 3)
			if not hard_pool.is_empty(): pool = hard_pool
		elif atlas.active_trial.kind == "breadth":
			var new_skills: Array = pool.filter(func(x):return not atlas.active_trial.skills.has(x.skill))
			if not new_skills.is_empty(): pool = new_skills
	elif atlas.data().review and atlas.claimed("f12"):
		var review_pool: Array = pool.filter(func(x):return s.weights.get(str(x.id),1.0)>1.0)
		if not review_pool.is_empty(): pool = review_pool
	var total := 0.0
	for x in pool:
		total += s.weights.get(str(x.id), 1.0)
	var r := randf() * total
	q = pool.back()
	for x in pool:
		r -= s.weights.get(str(x.id), 1.0)
		if r <= 0:
			q = x
			break
	last_id = q.id
	answered_current = false
	hint_used = false
	var col: Color = TIER_COLORS[q.diff - 1]
	tier_lbl.text = TIERS[q.diff - 1]
	tier_lbl.add_theme_stylebox_override("normal", _sb(col.darkened(0.6), col, 6, 1, 8, 2))
	tier_lbl.add_theme_color_override("font_color", col)
	qtext.text = q.q
	for i in 4:
		choice_btns[i].text = "%s    %s" % ["ABCD"[i], q.choices[i]]
		choice_btns[i].disabled = false
		choice_btns[i].remove_theme_stylebox_override("disabled")
		choice_btns[i].remove_theme_color_override("font_disabled_color")
	explain_panel.visible = false
	next_btn.visible = false
	hint_btn.visible = true


func _on_answer(i: int) -> void:
	if answered_current or i < 0 or i >= 4 or choice_btns[i].disabled:
		return
	answered_current = true
	var key := str(q.id)
	var st := sk(q.skill)
	var sec: Dictionary = s.sec[skill_of(q.skill).sec]
	st.a += 1
	sec.a += 1
	if i == q.a:
		var r := reward()
		pop_quiz = false
		if not test_mode and randf() * 100.0 < perk("lucky"):
			r *= 10.0
			_float_text("LUCKY  x10", C_GOLD)
			_play("event")
		_gain(r)
		s.streak += 1
		st.c += 1
		sec.c += 1
		s.life_correct += 1
		if q.diff == 3:
			s.hard_correct += 1
		var before := skill_level(q.skill)
		st.xp += q.diff + lvl("mnem") + atlas.xp_bonus()
		var after := skill_level(q.skill)
		if after > before:
			var msg := "%s reached Lv %d!" % [skill_of(q.skill).name, after]
			if after == 2 or after == 4:
				msg += "   %s questions unlocked" % TIERS[skill_tier(q.skill) - 1]
			_toast(msg)
			_float_text("LEVEL UP", C_CYAN)
			_play("levelup")
		else:
			_play("correct")
		s.weights[key] = max(0.3, s.weights.get(key, 1.0) * 0.6)
		explain.text = "CORRECT   +%s KP   +%d XP\n%s" % [fmt(r), q.diff + lvl("mnem") + atlas.xp_bonus(), q.explain]
		explain_panel.add_theme_stylebox_override("panel", _sb(C_GREEN.darkened(0.75), C_GREEN, 10))
		_mark(choice_btns[i], C_GREEN)
		_float_text("+%s KP" % fmt(r), C_GOLD)
		_pulse(kp_lbl)
		if s.streak in [5, 10, 25]:
			_float_text("%d STREAK!" % s.streak, C_ORANGE)
	else:
		if atlas.claimed("p09") and atlas.data().path == "precision" and atlas.data().hint_tokens > 0:
			atlas.data().hint_tokens -= 1
			_toast("Lens insurance protected your streak · one hint token used")
		else:
			s.streak = int(s.streak * 0.25 * lvl("chance"))
		s.weights[key] = min(10.0, s.weights.get(key, 1.0) * 3.0)
		explain.text = "WRONG   answer was %s\n%s" % ["ABCD"[q.a], q.explain]
		explain_panel.add_theme_stylebox_override("panel", _sb(C_RED.darkened(0.75), C_RED, 10))
		_mark(choice_btns[i], C_RED)
		_mark(choice_btns[q.a], C_GREEN)
		_float_text("streak lost" if s.streak == 0 else "streak -> %d" % s.streak, C_RED)
		_play("wrong")
	for b in choice_btns:
		b.disabled = true
	explain_panel.visible = true
	next_btn.visible = true
	hint_btn.visible = false
	atlas.on_answer(i == q.a)
	ui.core.pulse()
	if i == q.a: _spark_burst(ui.core.global_position + ui.core.size / 2 if ui.core.is_visible_in_tree() else kp_lbl.global_position + kp_lbl.size / 2)
	_check_achievements()
	_save()
	next_btn.grab_focus()


func _on_hint() -> void:
	var c := hint_cost()
	if answered_current or hint_used or (s.kp < c and atlas.data().hint_tokens < 1):
		return
	hint_used = true
	if atlas.data().hint_tokens > 0: atlas.data().hint_tokens -= 1
	else: s.kp -= c
	var wrong: Array = [0, 1, 2, 3].filter(func(i): return i != q.a and not choice_btns[i].disabled)
	wrong.shuffle()
	for i in wrong.slice(0, 2):
		choice_btns[i].disabled = true
	hint_btn.visible = false
	_save()


func _select_mode(id: String) -> void:
	if not atlas.active_trial.is_empty():
		_toast("Finish or end your current trial before switching skills.")
		return
	s.mode = id
	_next_question()
	_show("study")
	_save()


func _buy(u: Dictionary) -> void:
	var c := cost(u)
	if s.kp < c or lvl(u.id) >= u.get("max", 999) or upgrade_lock(u) != "":
		return
	s.kp -= c
	s.lvls[u.id] = lvl(u.id) + 1
	atlas.data().purchases += 1
	_toast("%s purchased · Level %d" % [u.name, lvl(u.id)])
	var b: Button = up_btns[u.id]
	_pulse(b)
	if b.is_visible_in_tree():
		_spark_burst(b.global_position + b.size / 2)
		_float_at("-%s KP" % fmt(ceil(c)), b.global_position + Vector2(b.size.x * 0.5, 6), C_RED)
	_pulse(kp_lbl)
	_play("buy")
	_check_achievements()
	_save()


func _take_test() -> void:
	var gain := _scholars_gain()
	if run_answered() < 20 or gain < 1:
		return
	var score := _psat_score()
	s.best_score = max(s.best_score, score)
	s.last_score = score
	s.scholars += gain
	s.tests += 1
	var keep := {"scholars": s.scholars, "best_score": s.best_score, "last_score": score, "tests": s.tests,
		"weights": s.weights, "skills": s.skills, "mode": s.mode, "life_correct": s.life_correct,
		"life_kp": s.life_kp, "hard_correct": s.hard_correct, "ach": s.ach, "muted": s.muted, "atlas": s.atlas, "save_version": 2}
	s = _default_state()
	s.merge(keep, true)
	atlas.active_trial = {}
	# Night Atlas head starts: KP and Study Group levels carried into the new run
	if perk("head_start") > 0: _gain(perk("head_start"))
	if perk("keep_group") > 0: s.lvls["group"] = int(perk("keep_group"))
	_toast("PSAT SCORE: %d    +%d Scholars  ->  all KP x%.1f" % [score, gain, scholar_mult()])
	_next_question()
	_show("study")
	_float_text("SCORE %d" % score, C_GOLD)
	_play("trophy")
	_check_achievements()
	_save()


# ---------- save ----------
func _save() -> void:
	if test_mode or s.is_empty(): return
	s.saved_at = int(Time.get_unix_time_from_system())
	if not _write_save(SAVE_PATH): push_error("Could not save PSAT Grind progress.")


func _write_save(path: String) -> bool:
	var temporary := path + ".tmp"
	var file := FileAccess.open(temporary, FileAccess.WRITE)
	if not file: return false
	file.store_string(JSON.stringify(s))
	file.flush()
	file.close()
	if FileAccess.file_exists(path):
		if DirAccess.copy_absolute(path, path + ".bak") != OK: return false
	return DirAccess.rename_absolute(temporary, path) == OK


func _apply_loaded(value: Dictionary) -> void:
	s = _default_state()
	s.merge(value, true)
	atlas.migrate()


func _load() -> void:
	_apply_loaded({})
	if test_mode: return
	if FileAccess.file_exists(SAVE_PATH):
		var d = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
		if not d is Dictionary and FileAccess.file_exists(SAVE_PATH + ".bak"):
			d = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH + ".bak"))
		if d is Dictionary:
			if not d.has("save_version") and not FileAccess.file_exists("user://save.pre-night-atlas.json"):
				DirAccess.copy_absolute(SAVE_PATH,"user://save.pre-night-atlas.json")
			_apply_loaded(d)
	var away := clampf(Time.get_unix_time_from_system() - s.saved_at, 0, offline_cap_h() * 3600)
	offline_gained = _passive_rate() * away
	if offline_gained >= 1: _gain(offline_gained)


func _confirm_test() -> void:
	var dialog := ConfirmationDialog.new()
	dialog.title = "Take the PSAT and prestige?"
	dialog.dialog_text = "Reset current KP, run stats and purchased upgrades for %d Scholars. Ends any active trial.\nKeep skill mastery, trophies, lifetime records and ALL Night Atlas progress." % _scholars_gain()
	add_child(dialog)
	dialog.confirmed.connect(func(): _take_test(); dialog.queue_free())
	dialog.canceled.connect(dialog.queue_free)
	dialog.popup_centered()


# ---------- ui ----------
func _sb(bg: Color, border := Color(0, 0, 0, 0), radius := 8, bw := 1, mx := 14, my := 10) -> StyleBoxFlat:
	var b := StyleBoxFlat.new()
	b.bg_color = bg
	b.border_color = border
	b.set_border_width_all(bw)
	b.set_corner_radius_all(radius)
	b.content_margin_left = mx
	b.content_margin_right = mx
	b.content_margin_top = my
	b.content_margin_bottom = my
	return b


func _make_theme() -> Theme:
	var th := Theme.new()
	var font := SystemFont.new()
	font.font_names = ["Bahnschrift", "Segoe UI", "Arial"]
	th.default_font = font
	th.default_font_size = 17
	th.set_color("font_color", "Label", C_TEXT)
	th.set_color("font_color", "Button", C_TEXT)
	th.set_color("font_hover_color", "Button", C_CYAN)
	th.set_color("font_pressed_color", "Button", C_CYAN)
	th.set_color("font_disabled_color", "Button", C_MUTED)
	var hover := _sb(C_PANEL2, C_CYAN)
	hover.shadow_color = Color(C_CYAN, 0.25)
	hover.shadow_size = 6
	th.set_stylebox("normal", "Button", _sb(C_PANEL2, C_BORDER))
	th.set_stylebox("hover", "Button", hover)
	th.set_stylebox("pressed", "Button", _sb(C_CYAN.darkened(0.7), C_CYAN))
	th.set_stylebox("disabled", "Button", _sb(C_PANEL, C_BORDER))
	th.set_stylebox("focus", "Button", _sb(Color.TRANSPARENT, C_GOLD, 8, 2))
	th.set_stylebox("panel", "PanelContainer", _sb(C_PANEL, C_BORDER, 12, 1, 18, 16))
	th.set_stylebox("background", "ProgressBar", _sb(C_BG, Color(0, 0, 0, 0), 3, 0, 0, 0))
	th.set_stylebox("fill", "ProgressBar", _sb(C_CYAN, Color(0, 0, 0, 0), 3, 0, 0, 0))
	return th


func _build_ui() -> void:
	ui = NightUI.new(self)
	ui.build()


func _build_study(parent: Node) -> Control:
	var card := PanelContainer.new()
	parent.add_child(card)
	var cv := VBoxContainer.new()
	cv.add_theme_constant_override("separation", 10)
	card.add_child(cv)
	var meta := BoxContainer.new()
	meta.add_theme_constant_override("separation", 10)
	cv.add_child(meta)
	skill_lbl = _label(meta, "", 14, C_MUTED)
	skill_lbl.size_flags_horizontal = SIZE_EXPAND_FILL
	tier_lbl = _label(meta, "", 13, C_GREEN)
	tier_lbl.custom_minimum_size.x = 62
	worth_lbl = _label(meta, "", 14, C_GOLD)
	worth_lbl.size_flags_horizontal = SIZE_EXPAND_FILL
	worth_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	var change := _button(meta, "change skill", _show.bind("skills"))
	change.add_theme_font_size_override("font_size", 13)
	qtext = _label(cv, "", 24, C_TEXT)
	qtext.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	cv.add_child(Control.new())
	for i in 4:
		var b := _button(cv, "", _on_answer.bind(i))
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		b.custom_minimum_size.y = 48
		choice_btns.append(b)
	explain_panel = PanelContainer.new()
	explain_panel.visible = false
	cv.add_child(explain_panel)
	explain = _label(explain_panel, "", 15, C_TEXT)
	explain.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	var spacer := Control.new()
	spacer.size_flags_vertical = SIZE_EXPAND_FILL
	cv.add_child(spacer)
	var row := BoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	cv.add_child(row)
	hint_btn = _button(row, "Hint", _on_hint)
	next_btn = _button(row, "NEXT  ->", _next_question)
	next_btn.add_theme_stylebox_override("normal", _sb(C_CYAN.darkened(0.6), C_CYAN))
	var keys := _label(row, "1–4 answer · H hint · Enter next · F2 screen", 13, C_MUTED)
	keys.size_flags_horizontal = SIZE_EXPAND_FILL
	keys.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	keys.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	keys.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return card


func _build_skills(parent: Node) -> Control:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 10)
	parent.add_child(box)
	_label(box, "PICK WHAT TO STUDY   //   level a skill to unlock harder (and more valuable) questions", 14, C_MUTED)
	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	grid.size_flags_vertical = SIZE_EXPAND_FILL
	box.add_child(grid)
	var all := [{"id": "mixed", "name": "Mixed Review", "sec": ""}] + SKILLS
	for k in all:
		var p := PanelContainer.new()
		p.size_flags_horizontal = SIZE_EXPAND_FILL
		p.size_flags_vertical = SIZE_EXPAND_FILL
		grid.add_child(p)
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", 6)
		p.add_child(v)
		_label(v, k.name, 18, C_CYAN if k.id == "mixed" else C_TEXT)
		_label(v, "all unlocked skills, Cross-Training bonus" if k.id == "mixed" else SEC_NAMES[k.sec], 13, C_MUTED)
		var bar := ProgressBar.new()
		bar.show_percentage = false
		bar.custom_minimum_size.y = 5
		bar.max_value = 1.0
		bar.visible = k.id != "mixed"
		v.add_child(bar)
		var info := _label(v, "", 13, C_TEXT)
		var sp := Control.new()
		sp.size_flags_vertical = SIZE_EXPAND_FILL
		v.add_child(sp)
		var btn := _button(v, "STUDY", _select_mode.bind(k.id))
		skill_cards[k.id] = {"bar": bar, "info": info, "btn": btn}
	return box


func _build_upgrades(parent: Node) -> Control:
	var row := BoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	parent.add_child(row)
	for g in GROUPS.size():
		var col := VBoxContainer.new()
		col.size_flags_horizontal = SIZE_EXPAND_FILL
		col.add_theme_constant_override("separation", 8)
		row.add_child(col)
		_label(col, GROUPS[g], 14, C_MUTED)
		for u in UPGRADES:
			if u.grp != g:
				continue
			var b := _button(col, "", _buy.bind(u))
			b.alignment = HORIZONTAL_ALIGNMENT_LEFT
			b.add_theme_font_size_override("font_size", 15)
			b.clip_text = true
			up_btns[u.id] = b
			var bar := ProgressBar.new()
			bar.show_percentage = false
			bar.custom_minimum_size.y = 5
			bar.max_value = 1.0
			col.add_child(bar)
			up_bars[u.id] = bar
	return row


func _build_psat(parent: Node) -> Control:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	parent.add_child(box)
	var pp := PanelContainer.new()
	pp.add_theme_stylebox_override("panel", _sb(C_GOLD.darkened(0.85), C_GOLD, 12, 1, 22, 18))
	box.add_child(pp)
	var pv := VBoxContainer.new()
	pv.add_theme_constant_override("separation", 8)
	pp.add_child(pv)
	_label(pv, "TAKE THE PSAT   //   prestige", 14, C_GOLD)
	score_lbl = _label(pv, "", 44, C_GOLD)
	score_breakdown = _label(pv, "", 15, C_TEXT)
	prestige_info = _label(pv, "", 14, C_MUTED)
	prestige_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	prestige_btn = _button(pv, "", _confirm_test)
	prestige_btn.add_theme_stylebox_override("normal", _sb(C_GOLD, C_GOLD))
	prestige_btn.add_theme_color_override("font_color", C_BG)
	prestige_btn.add_theme_stylebox_override("hover", _sb(C_GOLD.lightened(0.2), C_GOLD))
	var hp := PanelContainer.new()
	box.add_child(hp)
	var hv := VBoxContainer.new()
	hp.add_child(hv)
	_label(hv, "HOW IT WORKS", 14, C_MUTED)
	var how := _label(hv, "Your score (320-1520) comes from this run's accuracy in each section, boosted by how many question tiers you've unlocked. Taking the test resets KP and upgrades but keeps skill mastery, and every Scholar permanently multiplies all KP by +10%.", 14, C_TEXT)
	how.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	history_lbl = _label(hv, "", 14, C_TEXT)
	var tp := PanelContainer.new()
	box.add_child(tp)
	var tv := VBoxContainer.new()
	tv.add_theme_constant_override("separation", 8)
	tp.add_child(tv)
	_label(tv, "TROPHIES   //   each one is a permanent +5% KP", 14, C_MUTED)
	var flow := HFlowContainer.new()
	flow.add_theme_constant_override("h_separation", 8)
	flow.add_theme_constant_override("v_separation", 8)
	tv.add_child(flow)
	for a in ACHIEVEMENTS:
		var l := _chip(flow, C_MUTED)
		l.text = "%s\n%s" % [a.name, a.desc]
		trophy_lbls[a.id] = l
	return box


func _show(name: String) -> void:
	if ui: ui.show_screen(name)
	if player:
		_play("click")
	for n in screens:
		screens[n].visible = n == name
		var b: Button = nav_btns[n]
		if n == name:
			b.add_theme_stylebox_override("normal", _sb(C_CYAN.darkened(0.6), C_CYAN))
			b.add_theme_color_override("font_color", C_CYAN)
		else:
			b.remove_theme_stylebox_override("normal")
			b.remove_theme_color_override("font_color")


func _label(parent: Node, text := "", size := 17, col := C_TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	parent.add_child(l)
	return l


func _chip(parent: Node, col: Color) -> Label:
	var l := _label(parent, "", 14, col)
	l.add_theme_stylebox_override("normal", _sb(C_PANEL, col.darkened(0.4), 8, 1, 12, 5))
	return l


func _button(parent: Node, text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = FOCUS_ALL
	b.mouse_default_cursor_shape = CURSOR_POINTING_HAND
	b.button_down.connect(func(): if not s.get("atlas", {}).get("reduced_motion",false): _pulse(b))
	b.pressed.connect(cb)
	parent.add_child(b)
	return b


func _mark(b: Button, col: Color) -> void:
	b.add_theme_stylebox_override("disabled", _sb(col.darkened(0.7), col))
	b.add_theme_color_override("font_disabled_color", col)


func _float_text(txt: String, col: Color) -> void:
	if not qtext: return
	var stacked := get_tree().get_nodes_in_group("reward_fx").filter(func(n): return n is Label).size()
	var position_hint := qtext.global_position + Vector2(qtext.size.x * 0.5, -34 - 26 * stacked)
	_float_at(txt, position_hint, col)


func _float_at(txt: String, at: Vector2, col: Color) -> void:
	if not is_inside_tree(): return
	if get_tree().get_nodes_in_group("reward_fx").size() >= 12: return
	var label := _label(self, txt, 22, col)
	label.add_to_group("reward_fx")
	label.mouse_filter = MOUSE_FILTER_IGNORE
	label.position = at - global_position - Vector2(40, 0)
	var tw := create_tween().set_parallel()
	if not s.get("atlas",{}).get("reduced_motion",false):
		tw.tween_property(label,"position:y",label.position.y-45,.65).set_ease(Tween.EASE_OUT)
	tw.tween_property(label,"modulate:a",0.0,.45).set_delay(.25)
	tw.chain().tween_callback(label.queue_free)


func _pulse(c: Control) -> void:
	if not is_instance_valid(c) or s.get("atlas",{}).get("reduced_motion",false): return
	c.pivot_offset = c.size / 2
	c.scale = Vector2(1.035, 1.035)
	create_tween().tween_property(c, "scale", Vector2.ONE, .18).set_ease(Tween.EASE_OUT)


func _progress_to(bar: ProgressBar, value: float) -> void:
	if is_equal_approx(float(bar.get_meta("target", -1.0)),value): return
	bar.set_meta("target",value)
	var previous = bar.get_meta("motion") if bar.has_meta("motion") else null
	if previous is Tween and previous.is_valid(): previous.kill()
	if s.get("atlas",{}).get("reduced_motion",false): bar.value=value;return
	var animation:=create_tween()
	animation.tween_property(bar,"value",value,.18)
	bar.set_meta("motion",animation)


func _spark_burst(at: Vector2) -> void:
	if s.get("atlas",{}).get("reduced_motion",false): return
	for i in 8:
		if get_tree().get_nodes_in_group("reward_fx").size()>=24:break
		var spark:=ColorRect.new()
		spark.add_to_group("reward_fx")
		spark.color=C_CYAN if i%2==0 else C_GOLD
		spark.size=Vector2(4,4)
		spark.mouse_filter=MOUSE_FILTER_IGNORE
		add_child(spark)
		spark.position=at-global_position
		var tw:=create_tween().set_parallel()
		tw.tween_property(spark,"position",spark.position+Vector2.from_angle(TAU*i/8)*55,.4).set_ease(Tween.EASE_OUT)
		tw.tween_property(spark,"modulate:a",0.0,.4)
		tw.chain().tween_callback(spark.queue_free)


func _toast(msg: String) -> void:
	if not toast:
		return
	toast.text = msg
	get_tree().create_timer(6.0).timeout.connect(func(): if toast.text == msg: toast.text = "")


func _refresh() -> void:
	kp_lbl.text = "%s KP" % fmt(s.kp)
	rate_lbl.text = "+%s / sec" % fmt(_passive_rate())
	streak_lbl.text = "STREAK %d   x%.2f" % [s.streak, streak_mult()]
	scholar_lbl.text = "SCHOLARS %d   KP x%.1f" % [s.scholars, scholar_mult()]
	best_lbl.text = "BEST PSAT %d   ·   TROPHIES %d/%d" % [s.best_score, s.ach.size(), ACHIEVEMENTS.size()]
	var left := bonus_until - Time.get_ticks_msec() / 1000.0
	event_chip.visible = left > 0 or pop_quiz
	event_chip.text = ("POP QUIZ: next correct 5x" if pop_quiz else "") + ("   " if pop_quiz and left > 0 else "") + ("2x KP  %ds" % int(left) if left > 0 else "")
	if screens["study"].visible and not q.is_empty():
		var kname: String = "MIXED REVIEW" if s.mode == "mixed" else skill_of(s.mode).name.to_upper()
		skill_lbl.text = "%s   ·   %s Lv %d" % [kname, skill_of(q.skill).name, skill_level(q.skill)]
		worth_lbl.text = "worth %s KP" % fmt(reward())
		hint_btn.text = "Hint · %d free tokens" % atlas.data().hint_tokens if atlas.data().hint_tokens > 0 else "Remove 2 wrong · %s KP" % fmt(ceil(hint_cost()))
		hint_btn.disabled = s.kp < hint_cost() and atlas.data().hint_tokens < 1
	elif screens["skills"].visible:
		for k in SKILLS:
			var c: Dictionary = skill_cards[k.id]
			var st := sk(k.id)
			var l := skill_level(k.id)
			var lo := xp_for_level(l)
			var hi := xp_for_level(l + 1)
			_progress_to(c.bar, (st.xp - lo) / (hi - lo))
			var acc: String = ("%d%%" % int(100.0 * st.c / st.a)) if st.a > 0 else "--"
			var next_unlock: String = "MEDIUM questions unlock at Lv 2" if l < 2 else ("HARD questions unlock at Lv 4" if l < 4 else "all tiers unlocked · +%d%% KP from mastery" % int(l * (10 + 5 * lvl("mastery"))))
			c.info.text = "Lv %d   %d / %d XP   ·   accuracy %s\n%s" % [l, st.xp, hi, acc, next_unlock]
			c.bar.modulate = TIER_COLORS[skill_tier(k.id) - 1]
			c.btn.disabled = s.mode == k.id
			c.btn.text = "STUDYING" if s.mode == k.id else "STUDY"
		var m: Dictionary = skill_cards["mixed"]
		m.info.text = "%d questions unlocked" % questions.filter(func(x): return x.diff <= skill_tier(x.skill)).size()
		m.btn.disabled = s.mode == "mixed"
		m.btn.text = "STUDYING" if s.mode == "mixed" else "STUDY"
	elif screens["upgrades"].visible:
		_refresh_upgrades()
	elif screens["psat"].visible:
		var gain := _scholars_gain()
		score_lbl.text = "%d" % _psat_score()
		score_breakdown.text = "Math %d  (%d/%d)      Reading & Writing %d  (%d/%d)" % [
			sec_score("Math"), s.sec.Math.c, s.sec.Math.a, sec_score("RW"), s.sec.RW.c, s.sec.RW.a]
		prestige_info.text = "Needs 20+ answers this run (%d so far) and 500+ KP earned this run (%s so far)." % [run_answered(), fmt(s.run_kp)]
		prestige_btn.text = "TAKE THE TEST   +%d Scholars" % gain
		prestige_btn.disabled = run_answered() < 20 or gain < 1
		history_lbl.text = "Tests taken: %d   ·   Last score: %d   ·   Best: %d   ·   Scholars: %d   ·   Lifetime: %d correct, %s KP" % [
			s.tests, s.last_score, s.best_score, s.scholars, s.life_correct, fmt(s.life_kp)]
		for a in ACHIEVEMENTS:
			var l: Label = trophy_lbls[a.id]
			var got: bool = a.id in s.ach
			l.add_theme_color_override("font_color", C_GOLD if got else C_MUTED)
			l.add_theme_stylebox_override("normal", _sb(C_GOLD.darkened(0.8) if got else C_PANEL, C_GOLD if got else C_BORDER, 8, 1, 12, 5))


## Upgrade gate: the 3rd and 4th upgrade of each column unlock once the previous one reaches Lv 2.
func upgrade_lock(u: Dictionary) -> String:
	var column: Array = UPGRADES.filter(func(x): return x.grp == u.grp)
	var idx: int = column.find(u)
	if idx < 2: return ""
	var prev: Dictionary = column[idx - 1]
	return "" if lvl(prev.id) >= 2 else "%s Lv 2" % prev.name


func upgrade_state(u: Dictionary) -> String:
	var c := cost(u)
	if lvl(u.id) >= u.get("max", 999): return "MAXED"
	if upgrade_lock(u) != "": return "LOCKED"
	if s.kp >= c: return "AFFORDABLE"
	return "ALMOST" if s.kp >= c * 0.7 else "AVAILABLE"


## The recommended next purchase: the cheapest unlocked, unmaxed upgrade.
func recommended_upgrade() -> String:
	var best := ""
	var best_cost := INF
	for u in UPGRADES:
		var st := upgrade_state(u)
		if st in ["MAXED", "LOCKED"]: continue
		if cost(u) < best_cost:
			best_cost = cost(u)
			best = u.id
	return best


func _refresh_upgrades() -> void:
	var next_id := recommended_upgrade()
	var first := seen_unlocked.is_empty()
	for u in UPGRADES:
		var b: Button = up_btns[u.id]
		var l := lvl(u.id)
		var c := cost(u)
		var st := upgrade_state(u)
		var col: Color = {"MAXED": C_GOLD, "LOCKED": C_MUTED, "AFFORDABLE": C_CYAN, "ALMOST": C_ORANGE, "AVAILABLE": C_BORDER}[st]
		var tag: String = {"MAXED": "MAXED", "LOCKED": "LOCKED · needs " + upgrade_lock(u), "AFFORDABLE": "BUY", "ALMOST": "ALMOST", "AVAILABLE": ""}[st]
		if u.id == next_id and st != "LOCKED":
			tag = "★ NEXT" + ("" if tag == "" else " · " + tag)
		b.text = "%s   Lv %d%s\n%s" % [u.name, l, ("   " + tag) if tag != "" else "", "?" if st == "LOCKED" else "%s KP   ·   %s" % [fmt(ceil(c)), u.desc]]
		b.tooltip_text = ("Locked. Reach %s to reveal this upgrade." % upgrade_lock(u)) if st == "LOCKED" else "%s\nLevel %d now%s\nCost grows x%.1f per level%s" % [u.desc, l, "" if st == "MAXED" else "  →  Lv %d for %s KP" % [l + 1, fmt(ceil(c))], u.mult, "\nMax level %d" % u.max if u.has("max") else ""]
		b.disabled = st in ["MAXED", "LOCKED"] or s.kp < c
		var style := _sb(col.darkened(0.82) if st in ["MAXED", "AFFORDABLE"] else C_PANEL2, col)
		if st == "AFFORDABLE" or u.id == next_id and st != "LOCKED":
			style.shadow_color = Color(col if st == "AFFORDABLE" else C_GOLD, 0.22)
			style.shadow_size = 6
		b.add_theme_stylebox_override("normal", style)
		b.add_theme_stylebox_override("disabled", style if st != "LOCKED" else _sb(C_BG, C_BORDER))
		b.add_theme_color_override("font_disabled_color", C_GOLD if st == "MAXED" else (C_MUTED.darkened(0.3) if st == "LOCKED" else C_TEXT))
		b.add_theme_color_override("font_color", C_CYAN if st == "AFFORDABLE" else C_TEXT)
		b.modulate.a = 0.6 if st == "LOCKED" else 1.0
		if st != "LOCKED" and not u.id in seen_unlocked:
			seen_unlocked.append(u.id)
			if not first:
				_pulse(b)
				_toast("New upgrade revealed: %s" % u.name)
		_progress_to(up_bars[u.id], 1.0 if st == "MAXED" else (0.0 if st == "LOCKED" else clampf(s.kp / c, 0.0, 1.0)))
		up_bars[u.id].modulate = col if st in ["MAXED", "AFFORDABLE", "ALMOST"] else C_TEXT


# ---------- self-check ----------
func _selftest() -> void:
	var ids := SKILLS.map(func(k): return k.id)
	for x in questions:
		assert(x.choices.size() == 4 and x.a >= 0 and x.a < 4 and x.diff >= 1 and x.diff <= 3 and x.skill in ids, "bad question: " + str(x.q))
	for id in ids:
		assert(questions.any(func(x): return x.skill == id and x.diff == 1), "skill has no easy questions: " + id)
	s = _default_state()
	q = questions[0]
	assert(reward() == 10.0 * q.diff)
	s.lvls = {"flash": 2, "focus": 1}
	s.streak = 10
	s.scholars = 5
	assert(is_equal_approx(reward(), 20.0 * q.diff * 2.0 * 1.5))
	sk("alg").xp = 16
	assert(skill_level("alg") == 2 and skill_tier("alg") == 2)
	s.sec.Math = {"c": 10, "a": 20}
	s.sec.RW = {"c": 20, "a": 20}
	assert(sec_score("Math") == 160 + int(600 * 0.5 * (0.5 + 0.25 * 0.25)), str(sec_score("Math")))
	assert(sec_score("RW") == 460)
	s.ach = ["first", "hard"]
	assert(is_equal_approx(trophy_mult(), 1.1))
	s.life_correct = 100
	_check_achievements()
	assert("c100" in s.ach and "lv2" in s.ach and not ("lv4" in s.ach))
	assert(_make_sound([440], 0.1, true).data.size() == 2 * 2205)
	print("selftest ok: %d questions, %d trophies" % [questions.size(), ACHIEVEMENTS.size()])
